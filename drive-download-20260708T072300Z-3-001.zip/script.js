// =============================================
// CONFIG
// =============================================
const API = '';
let token = localStorage.getItem('repair_token') || '';
let currentUser = JSON.parse(localStorage.getItem('repair_user') || 'null');
let currentRepairId = null;
let equipTypes = [];

// =============================================
// INIT
// =============================================
(function init() {
  const path = window.location.pathname;

  // หน้าล็อกอินกับสมัคร ไม่ต้องเช็ค auth
  if (path.includes('index.html') || path === '/' || path.includes('register.html')) return;

  // หน้าอื่นต้องมี token
  if (!token || !currentUser) {
    window.location.href = 'index.html';
    return;
  }

  // แสดงชื่อบน topbar
  const nameEl = document.getElementById('topbar-uname');
  if (nameEl) nameEl.textContent = currentUser.full_name || currentUser.username;

  // แสดงบทบาทผู้ใช้ (รองรับ Manager)
  const roleEl = document.getElementById('topbar-role');
  if (roleEl) {
    if (currentUser.role === 'admin') {
      roleEl.textContent = '👑 Admin';
      roleEl.style.background = 'rgba(232,93,38,0.2)';
      roleEl.style.color = '#e85d26';
    } else if (currentUser.role === 'manager') {
      roleEl.textContent = '👔 Manager';
      roleEl.style.background = 'rgba(139,92,246,0.2)';
      roleEl.style.color = '#8b5cf6';
    } else {
      roleEl.textContent = '👤 User';
      roleEl.style.background = 'rgba(59,130,246,0.2)';
      roleEl.style.color = '#3b82f6';
    }
  }

  // Sidebar
  initSidebar();

  // Role-Based Access Control
  initMenuByRole();
  if (!checkPageAccess()) return;

  // Dark Mode
  initDarkMode();

  // โหลดข้อมูลตามหน้า
  loadEquipTypes();
  if (path.includes('manager-dashboard.html')) loadManagerDashboard();
  if (path.includes('dashboard.html')) loadDashboard();
  if (path.includes('repair-form.html')) initRepairForm();
  if (path.includes('history.html')) loadHistory();
  if (path.includes('my-history.html')) loadMyHistory();
  if (path.includes('service.html')) loadServiceData();
  // equipment.html และ type-select.html จัดการเอง (มี script เฉพาะหน้า)
})();

// =============================================
// SIDEBAR
// =============================================
function initSidebar() {
  const userNameEl = document.getElementById('sidebar-user-name');
  const userRoleEl = document.getElementById('sidebar-user-role');
  if (userNameEl) userNameEl.textContent = currentUser.full_name || currentUser.username;
  if (userRoleEl) {
    userRoleEl.textContent = currentUser.role === 'admin' ? '👑 Admin' : '👤 ผู้ใช้งาน';
  }

  // Set active nav
  const path = window.location.pathname;
  document.querySelectorAll('#sidebar .nav-btn').forEach(btn => {
    const href = btn.getAttribute('href');
    if (href && path.includes(href)) {
      btn.classList.add('active');
    }
  });
}

function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  if (sidebar) sidebar.classList.toggle('open');
  if (overlay) overlay.classList.toggle('active');
}

function closeSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  if (sidebar) sidebar.classList.remove('open');
  if (overlay) overlay.classList.remove('active');
}

// =============================================
// DARK MODE
// =============================================
function initDarkMode() {
  const saved = localStorage.getItem('repair_theme');
  if (saved === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
  const toggle = document.getElementById('theme-toggle');
  if (toggle) {
    toggle.textContent = saved === 'dark' ? '☀️' : '🌙';
    toggle.onclick = toggleDarkMode;
  }
}

function toggleDarkMode() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  if (isDark) {
    html.removeAttribute('data-theme');
    localStorage.setItem('repair_theme', 'light');
  } else {
    html.setAttribute('data-theme', 'dark');
    localStorage.setItem('repair_theme', 'dark');
  }
  const toggle = document.getElementById('theme-toggle');
  if (toggle) toggle.textContent = isDark ? '🌙' : '☀️';
}

// =============================================
// RBAC
// =============================================
function initMenuByRole() {
  if (currentUser && currentUser.role !== 'admin') {
    document.querySelectorAll('.admin-only').forEach(el => {
      el.style.display = 'none';
    });
  }
}

function checkPageAccess() {
  const path = window.location.pathname;
  // Admin-only pages (User cannot access these)
  const adminPages = ['dashboard.html', 'history.html', 'user-management.html'];
  const isAdminPage = adminPages.some(p => path.includes(p));
  if (isAdminPage && currentUser.role !== 'admin') {
    if (currentUser.role === 'manager') {
      window.location.href = 'manager-dashboard.html';
    } else {
      window.location.href = 'my-history.html';
    }
    return false;
  }
  return true;
}

// =============================================
// AUTH
// =============================================
async function doLogin() {
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  const errEl = document.getElementById('login-err');
  errEl.style.display = 'none';
  if (!username || !password) { showErr(errEl, 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน'); return; }
  try {
    const res = await api('POST', '/api/auth/login', { username, password }, false);
    if (res.success) {
      token = res.token;
      currentUser = res.user;
      localStorage.setItem('repair_token', token);
      localStorage.setItem('repair_user', JSON.stringify(currentUser));
      if (res.user.role === 'admin') {
        window.location.href = 'dashboard.html';
      } else if (res.user.role === 'manager') {
        window.location.href = 'manager-dashboard.html';
      } else {
        window.location.href = 'my-history.html';
      }
    } else { showErr(errEl, res.message); }
  } catch (e) { showErr(errEl, 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้'); }
}

async function doRegister() {
  const full_name = document.getElementById('reg-fullname').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const phone = document.getElementById('reg-phone').value.trim();
  const username = document.getElementById('reg-username').value.trim();
  const password = document.getElementById('reg-password').value;
  const confirm_password = document.getElementById('reg-confirm-password').value;
  const errEl = document.getElementById('reg-err');
  const okEl = document.getElementById('reg-ok');
  errEl.style.display = okEl.style.display = 'none';
  if (!full_name || !email || !username || !password) {
    showErr(errEl, 'กรุณากรอกข้อมูลให้ครบ (ชื่อ-นามสกุล, อีเมล, ชื่อผู้ใช้, รหัสผ่าน)'); return;
  }
  if (password.length < 6) { showErr(errEl, 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร'); return; }
  if (password !== confirm_password) { showErr(errEl, 'รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน'); return; }
  try {
    const res = await api('POST', '/api/auth/register', { username, password, full_name, email, phone }, false);
    if (res.success) { okEl.textContent = '✅ ลงทะเบียนสำเร็จ! กำลังเข้าสู่ระบบ...'; okEl.style.display = 'block'; setTimeout(() => { window.location.href = 'index.html'; }, 1500); }
    else { showErr(errEl, res.message); }
  } catch (e) { showErr(errEl, 'เกิดข้อผิดพลาด กรุณาลองอีกครั้ง'); }
}

function doLogout() {
  token = ''; currentUser = null;
  localStorage.removeItem('repair_token');
  localStorage.removeItem('repair_user');
  window.location.href = 'index.html';
}

// =============================================
// API HELPER
// =============================================
async function api(method, url, data = null, auth = true) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && token) headers['Authorization'] = `Bearer ${token}`;
  const opts = { method, headers };
  if (data && method !== 'GET') opts.body = JSON.stringify(data);
  const res = await fetch(API + url, opts);
  if (res.status === 401) { doLogout(); throw new Error('Unauthorized'); }
  return res.json();
}

async function apiForm(method, url, formData) {
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(API + url, { method, headers, body: formData });
  return res.json();
}

// =============================================
// EQUIPMENT TYPES
// =============================================
async function loadEquipTypes() {
  try {
    const res = await api('GET', '/api/equipment-types');
    if (res.success) {
      equipTypes = res.data;
      populateTypeSelects();
      renderTypeGrid();
    }
  } catch {}
}

function populateTypeSelects() {
  const selects = ['rf-type', 'me-type', 'equip-type-filter'];
  selects.forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const extra = id === 'equip-type-filter' ? '<option value="">ทุกประเภท</option>' : '<option value="">-- เลือกประเภท --</option>';
    sel.innerHTML = extra + equipTypes.map(t => `<option value="${t.id}">${t.name}</option>`).join('');
  });
}

// =============================================
// DASHBOARD
// =============================================
let chartMonthly = null;
let chartStatusPie = null;

async function loadDashboard() {
  if (!document.getElementById('stat-total')) return;
  try {
    const dateFrom = document.getElementById('dash-date-start')?.value || '';
    const dateTo = document.getElementById('dash-date-end')?.value || '';
    let apiUrl = '/api/dashboard/stats?';
    if (dateFrom) apiUrl += `date_from=${encodeURIComponent(dateFrom)}&`;
    if (dateTo) apiUrl += `date_to=${encodeURIComponent(dateTo)}&`;

    const res = await api('GET', apiUrl);
    if (!res.success) return;
    document.getElementById('stat-total').textContent = res.stats.total;
    document.getElementById('stat-pending').textContent = res.stats.pending;
    document.getElementById('stat-inprogress').textContent = res.stats.in_progress;
    document.getElementById('stat-completed').textContent = res.stats.completed;
    document.getElementById('stat-urgent').textContent = res.stats.urgent;

    let recentUrl = '/api/repairs?limit=5';
    if (dateFrom) recentUrl += `&date_from=${dateFrom}`;
    if (dateTo) recentUrl += `&date_to=${dateTo}`;
    const recent = await api('GET', recentUrl);
    const tbody = document.getElementById('dash-recent');
    if (recent.success && recent.data.length) {
      tbody.innerHTML = recent.data.map(r => `<tr style="cursor:pointer" onclick="openService(${r.id})"><td style="font-family:'Space Mono';font-size:12px">${r.ticket_number}</td><td>${r.equipment_name}</td><td>${r.requester_name}</td><td>${statusBadge(r.status)}</td></tr>`).join('');
    } else { tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:24px">ยังไม่มีคำแจ้งซ่อม</td></tr>'; }

    const byType = document.getElementById('dash-bytype');
    if (res.byType && res.byType.length) {
      byType.innerHTML = res.byType.map(t => `<div style="display:flex;justify-content:space-between;margin-bottom:12px;"><span>${t.name}</span><div><div style="width:120px;height:8px;background:#f0f2f5;border-radius:4px;overflow:hidden"><div style="width:${Math.min(100,(t.count/res.stats.total*100)||0)}%;height:100%;background:var(--accent);border-radius:4px"></div></div><span style="margin-left:10px;">${t.count}</span></div></div>`).join('');
    }

    renderMonthlyChart(res.monthly || []);
    renderStatusPieChart(res.stats);
  } catch (e) { console.error(e); }
}

function renderMonthlyChart(data) {
  const ctx = document.getElementById('chart-monthly');
  if (!ctx) return;
  if (chartMonthly) chartMonthly.destroy();

  const labels = data.map(d => d.month);
  const counts = data.map(d => d.count);

  chartMonthly = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'จำนวนคำแจ้งซ่อม',
        data: counts,
        backgroundColor: 'rgba(232, 93, 38, 0.7)',
        borderColor: '#e85d26',
        borderWidth: 1,
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, ticks: { stepSize: 1 } }
      }
    }
  });
}

function renderStatusPieChart(stats) {
  const ctx = document.getElementById('chart-status-pie');
  if (!ctx) return;
  if (chartStatusPie) chartStatusPie.destroy();

  chartStatusPie = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['รอดำเนินการ', 'กำลังดำเนินการ', 'ส่งซ่อม', 'ซ่อมสำเร็จ'],
      datasets: [{
        data: [stats.pending || 0, stats.in_progress || 0, stats.sent_repair || 0, stats.completed || 0],
        backgroundColor: ['#f59e0b', '#3b82f6', '#8b5cf6', '#10b981'],
        borderWidth: 2,
        borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true } }
      }
    }
  });
}

// =============================================
// EQUIPMENT
// =============================================
async function loadEquipment() {
  if (!document.getElementById('equip-table')) return;
  const search = document.getElementById('equip-search')?.value || '';
  const type_id = document.getElementById('equip-type-filter')?.value || '';
  let url = '/api/equipment?';
  if (search) url += `search=${encodeURIComponent(search)}&`;
  if (type_id) url += `type_id=${type_id}`;
  try {
    const res = await api('GET', url);
    const tbody = document.getElementById('equip-table');
    if (res.success && res.data.length) {
      tbody.innerHTML = res.data.map(e => `<tr><td style="font-family:'Space Mono';font-size:12px">${e.equipment_code}</td><td>${e.equipment_name}</td><td>${e.type_name}</td><td>${e.location_building || '-'}</td><td>${e.location_department || '-'}</td><td>${e.location_room || '-'}</td><td><button class="btn btn-danger btn-sm" onclick="deleteEquip(${e.id},'${e.equipment_name}')">🗑️ ลบ</button></td></tr>`).join('');
    } else { tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:32px">ไม่พบครุภัณฑ์</td></tr>'; }
  } catch {}
}

async function submitEquipment() {
  const code = document.getElementById('me-code').value.trim();
  const name = document.getElementById('me-name').value.trim();
  const type = document.getElementById('me-type').value;
  const alertEl = document.getElementById('equip-modal-alert');
  if (!code || !name || !type) { alertEl.innerHTML = '<div class="alert alert-error">กรุณากรอกข้อมูลที่จำเป็น</div>'; return; }
  try {
    const res = await api('POST', '/api/equipment', {
      equipment_code: code, equipment_name: name, equipment_type_id: type,
      location_building: document.getElementById('me-building').value,
      location_department: document.getElementById('me-dept').value,
      location_room: document.getElementById('me-room').value
    });
    if (res.success) { closeModal('modal-equip'); loadEquipment(); }
    else { alertEl.innerHTML = `<div class="alert alert-error">${res.message}</div>`; }
  } catch {}
}

async function deleteEquip(id, name) {
  if (!confirm(`ต้องการลบ "${name}" ออกจากระบบ?`)) return;
  try {
    const res = await api('DELETE', `/api/equipment/${id}`);
    if (res.success) loadEquipment();
    else alert(res.message);
  } catch {}
}

// =============================================
// TYPE SELECT
// =============================================
function renderTypeGrid() {
  const grid = document.getElementById('type-grid');
  if (!grid) return;
  const icons = { 'คอมพิวเตอร์': '🖥️', 'เครื่องถ่ายเอกสาร': '🖨️', 'UPS': '🔋', 'Router': '📡' };
  grid.innerHTML = equipTypes.map(t => `<div class="type-card" onclick="selectTypeAndGo(${t.id})"><div class="tc-icon">${icons[t.name] || '📦'}</div><h3>${t.name}</h3><p>${t.has_parts ? 'เลือกชิ้นส่วนที่ซ่อมได้' : 'ส่งซ่อมทั้งเครื่อง'}</p></div>`).join('');
}

function selectTypeAndGo(typeId) {
  window.location.href = `equipment.html?type_id=${typeId}`;
}

// =============================================
// REPAIR FORM
// =============================================
function initRepairForm() {
  populateTypeSelects();
}

function onTypeChange() {
  const typeId = document.getElementById('rf-type')?.value;
  const type = equipTypes.find(t => t.id == typeId);
  const partsSection = document.getElementById('parts-section');
  if (partsSection) partsSection.style.display = (type && type.has_parts) ? 'block' : 'none';
  if (type && type.has_parts) {
    const partsGrid = document.getElementById('parts-grid');
    if (partsGrid) partsGrid.innerHTML = (type.parts || []).map(p => `<label class="part-check"><input type="checkbox" name="part" value="${p.part_name}">${p.part_name}</label>`).join('');
  }
  const equipInfoBox = document.getElementById('equip-info-box');
  if (equipInfoBox) equipInfoBox.style.display = 'none';
  const rfEquipCode = document.getElementById('rf-equip-code');
  if (rfEquipCode) rfEquipCode.value = '';
}

// =============================================
// LOOKUP EQUIPMENT (ปรับปรุงสำหรับรูปแบบใหม่)
// =============================================

async function lookupEquip() {
  const input = document.getElementById('rf-equip-code');
  let code = input.value.trim();
  
  if (!code) {
    showToast('⚠️ กรุณากรอกรหัสครุภัณฑ์', 'error');
    input.focus();
    return;
  }
  
  // ✅ ลบ - และ / ออกเพื่อค้นหา
  const searchCode = code.replace(/[-/]/g, '');
  
  // แสดงสถานะ
  const box = document.getElementById('equip-info-box');
  const searchBtn = document.getElementById('btn-search-equip');
  
  if (searchBtn) {
    searchBtn.textContent = '⏳ กำลังค้นหา...';
    searchBtn.disabled = true;
    searchBtn.style.opacity = '0.6';
  }
  
  if (box) {
    box.style.display = 'block';
    box.innerHTML = `<div class="alert alert-info">🔍 กำลังค้นหาข้อมูล "${code}" ...</div>`;
  }
  
  try {
    // ค้นหาด้วยรหัสเต็ม (มี - และ /)
    let res = await api('GET', `/api/equipment?search=${encodeURIComponent(code)}`);
    
    if (res.success && res.data.length > 0) {
      if (res.data.length === 1) {
        displayEquipmentInfo(res.data[0]);
        showToast('✅ พบครุภัณฑ์: ' + res.data[0].equipment_code, 'success');
      } else {
        showEquipmentList(res.data);
      }
      return;
    }
    
    // ถ้าไม่พบ ลองค้นหาด้วยรหัสที่ลบ - และ / แล้ว
    res = await api('GET', `/api/equipment?search=${encodeURIComponent(searchCode)}`);
    
    if (res.success && res.data.length > 0) {
      if (res.data.length === 1) {
        displayEquipmentInfo(res.data[0]);
        showToast('✅ พบครุภัณฑ์: ' + res.data[0].equipment_code, 'success');
      } else {
        showEquipmentList(res.data);
      }
      return;
    }
    
    // ถ้ายังไม่พบ ให้แจ้งเตือน
    if (box) {
      box.innerHTML = `
        <div class="alert alert-error">❌ ไม่พบครุภัณฑ์ "${code}" ในระบบ</div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:8px;">
          💡 ตรวจสอบรูปแบบ: <strong>XXXX-XXX-XXXX/XX/XX</strong> (4ตัว-3ตัว-4ตัว/2ตัว/2ตัว)<br>
        </div>
      `;
      box.style.display = 'block';
    }
    showToast('❌ ไม่พบครุภัณฑ์ที่ค้นหา', 'error');
    window.currentEquipId = null;
    window.currentEquipData = null;
    
  } catch (error) {
    console.error('ค้นหาครุภัณฑ์ผิดพลาด:', error);
    if (box) {
      box.innerHTML = `<div class="alert alert-error">❌ ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้</div>`;
      box.style.display = 'block';
    }
    showToast('❌ เกิดข้อผิดพลาดในการค้นหา', 'error');
  } finally {
    if (searchBtn) {
      searchBtn.textContent = '🔍 ค้นหา';
      searchBtn.disabled = false;
      searchBtn.style.opacity = '1';
    }
  }
}

// ✅ แสดงข้อมูลครุภัณฑ์ที่พบ
function displayEquipmentInfo(e) {
  const box = document.getElementById('equip-info-box');
  if (!box) return;
  
  window.currentEquipId = e.id;
  window.currentEquipData = e;
  
  box.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;">
      <div>
        <div style="font-size:13px;color:var(--text-muted);margin-bottom:4px;">📦 ข้อมูลครุภัณฑ์ที่พบ</div>
        <div style="font-size:16px;font-weight:600;color:var(--text);">${e.equipment_name}</div>
        <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">
          รหัส: <strong style="color:var(--accent);font-family:'Courier New',monospace;">${e.equipment_code}</strong> 
          | ประเภท: ${e.type_name}
        </div>
        <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">
          📍 ${e.location_building || '-'} / ${e.location_department || '-'} / ห้อง ${e.location_room || '-'}
        </div>
      </div>
      <div>
        <span class="badge success" style="background:#dcfce7;color:#166534;padding:6px 14px;border-radius:20px;font-size:12px;">✅ พบแล้ว</span>
      </div>
    </div>
  `;
  box.style.display = 'block';
  box.style.border = '2px solid #22c55e';
  box.style.background = '#f0fdf4';
  
  // อัตโนมัติกรอกข้อมูล
  const buildingField = document.getElementById('rf-building');
  const deptField = document.getElementById('rf-dept');
  const roomField = document.getElementById('rf-room');
  const typeSelect = document.getElementById('rf-type');
  
  if (buildingField) buildingField.value = e.location_building || '';
  if (deptField) deptField.value = e.location_department || '';
  if (roomField) roomField.value = e.location_room || '';
  if (typeSelect) typeSelect.value = e.equipment_type_id;
  
  onTypeChange();
  
  if (e.has_parts && e.parts) {
    const partsSection = document.getElementById('parts-section');
    const partsGrid = document.getElementById('parts-grid');
    if (partsSection) partsSection.style.display = 'block';
    if (partsGrid) {
      partsGrid.innerHTML = e.parts.map(p => `
        <label class="part-check">
          <input type="checkbox" name="part" value="${p.part_name}">
          ${p.part_name}
        </label>
      `).join('');
    }
  }
}

// ✅ แสดงรายการครุภัณฑ์ที่พบ
function showEquipmentList(equipmentList) {
  const box = document.getElementById('equip-info-box');
  if (!box) return;
  
  let html = `
    <div style="font-size:13px;color:var(--text-muted);margin-bottom:12px;">
      🔍 พบ ${equipmentList.length} รายการ กรุณาเลือก:
    </div>
    <div style="max-height:200px;overflow-y:auto;display:flex;flex-direction:column;gap:6px;">
  `;
  
  equipmentList.forEach(e => {
    html += `
      <div class="equip-search-item" onclick="selectEquipment(${e.id})" 
           style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;cursor:pointer;transition:all 0.2s;display:flex;justify-content:space-between;align-items:center;background:var(--card);"
           onmouseover="this.style.borderColor='var(--accent)';this.style.background='rgba(232,93,38,0.05)'"
           onmouseout="this.style.borderColor='var(--border)';this.style.background='var(--card)'">
        <div>
          <strong style="color:var(--text);">${e.equipment_name}</strong>
          <span style="font-size:12px;color:var(--text-muted);margin-left:8px;font-family:'Courier New',monospace;">${e.equipment_code}</span>
          <div style="font-size:12px;color:var(--text-muted);">${e.type_name} | ${e.location_building || '-'} / ${e.location_department || '-'}</div>
        </div>
        <span style="font-size:20px;color:var(--accent);">→</span>
      </div>
    `;
  });
  
  html += `</div>`;
  
  box.innerHTML = html;
  box.style.display = 'block';
  box.style.border = '2px solid var(--accent)';
  box.style.background = '#fef9f5';
}

// ✅ เลือกครุภัณฑ์จากรายการ
async function selectEquipment(id) {
  try {
    const res = await api('GET', `/api/equipment/${id}`);
    if (res.success) {
      displayEquipmentInfo(res.data);
      // กรอกรหัสให้อัตโนมัติ
      document.getElementById('rf-equip-code').value = res.data.equipment_code;
      showToast('✅ เลือกครุภัณฑ์: ' + res.data.equipment_name, 'success');
    }
  } catch (error) {
    console.error('Error selecting equipment:', error);
    showToast('❌ เกิดข้อผิดพลาด', 'error');
  }
}

// ✅ แสดงข้อมูลครุภัณฑ์ที่พบ
  const box = document.getElementById('equip-info-box');
  if (!box) return;
  
  // เก็บค่า equipment_id
  window.currentEquipId = e.id;
  window.currentEquipData = e;
  
  // แสดงข้อมูล
  box.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;">
      <div>
        <div style="font-size:13px;color:var(--text-muted);margin-bottom:4px;">📦 ข้อมูลครุภัณฑ์ที่พบ</div>
        <div style="font-size:16px;font-weight:600;">${e.equipment_name}</div>
        <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">
          รหัส: <strong>${e.equipment_code}</strong> | ประเภท: ${e.type_name}
        </div>
        <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">
          📍 ${e.location_building || '-'} / ${e.location_department || '-'} / ห้อง ${e.location_room || '-'}
        </div>
      </div>
      <div>
        <span class="badge success" style="background:#dcfce7;color:#166534;">✅ พบแล้ว</span>
      </div>
    </div>
  `;
  box.style.display = 'block';
  box.style.border = '2px solid #22c55e';
  box.style.background = '#f0fdf4';
  
  // อัตโนมัติกรอกข้อมูลสถานที่
  const buildingField = document.getElementById('rf-building');
  const deptField = document.getElementById('rf-dept');
  const roomField = document.getElementById('rf-room');
  const typeSelect = document.getElementById('rf-type');
  
  if (buildingField) buildingField.value = e.location_building || '';
  if (deptField) deptField.value = e.location_department || '';
  if (roomField) roomField.value = e.location_room || '';
  if (typeSelect) typeSelect.value = e.equipment_type_id;
  
  // เรียก onTypeChange เพื่อแสดงชิ้นส่วน
  onTypeChange();
  
  // แสดงส่วนของชิ้นส่วนถ้ามี
  if (e.has_parts && e.parts) {
    const partsSection = document.getElementById('parts-section');
    const partsGrid = document.getElementById('parts-grid');
    if (partsSection) partsSection.style.display = 'block';
    if (partsGrid) {
      partsGrid.innerHTML = e.parts.map(p => `
        <label class="part-check">
          <input type="checkbox" name="part" value="${p.part_name}">
          ${p.part_name}
        </label>
      `).join('');
    }
  }

// ✅ แสดงรายการครุภัณฑ์ที่พบ (กรณีเจอหลายรายการ)
  const box = document.getElementById('equip-info-box');
  if (!box) return;
  
  let html = `
    <div style="font-size:13px;color:var(--text-muted);margin-bottom:12px;">
      🔍 พบ ${equipmentList.length} รายการ กรุณาเลือก:
    </div>
    <div style="max-height:200px;overflow-y:auto;">
  `;
  
  equipmentList.forEach(e => {
    html += `
      <div class="equip-search-item" onclick="selectEquipment(${e.id})" 
           style="padding:10px 14px;border:1px solid var(--border);border-radius:8px;margin-bottom:6px;cursor:pointer;transition:all 0.2s;display:flex;justify-content:space-between;align-items:center;"
           onmouseover="this.style.borderColor='var(--accent)';this.style.background='rgba(232,93,38,0.05)'"
           onmouseout="this.style.borderColor='var(--border)';this.style.background='transparent'">
        <div>
          <strong>${e.equipment_name}</strong>
          <span style="font-size:12px;color:var(--text-muted);margin-left:8px;">${e.equipment_code}</span>
          <div style="font-size:12px;color:var(--text-muted);">${e.type_name} | ${e.location_building || '-'} / ${e.location_department || '-'}</div>
        </div>
        <span style="font-size:20px;color:var(--accent);">→</span>
      </div>
    `;
  });
  
  html += `</div>`;
  
  box.innerHTML = html;
  box.style.display = 'block';
  box.style.border = '2px solid var(--accent)';
  box.style.background = '#fef9f5';

// ✅ เลือกครุภัณฑ์จากรายการ

  const parts = Array.from(document.querySelectorAll('input[name="part"]:checked')).map(c => c.value);
  const fd = new FormData();
  fd.append('equipment_id', equipId);
  fd.append('equipment_parts', parts.join(', '));
  fd.append('problem_description', problem);
  fd.append('requester_name', requester);
  fd.append('location_building', building);
  fd.append('location_department', dept);
  fd.append('location_room', room);
  fd.append('priority', document.getElementById('rf-priority')?.value || 'normal');
  const img = document.getElementById('rf-image')?.files[0];
  if (img) fd.append('image', img);

  try {
    const res = await apiForm('POST', '/api/repairs', fd);
    if (res.success) {
      if (alertEl) alertEl.innerHTML = `<div class="alert alert-success">✅ บันทึกคำแจ้งซ่อมสำเร็จ! หมายเลข: <strong>${res.ticket_number}</strong></div>`;
      resetRepairForm();
      setTimeout(() => { window.location.href = 'history.html'; }, 2500);
    } else { if (alertEl) alertEl.innerHTML = `<div class="alert alert-error">${res.message}</div>`; }
  } catch { if (alertEl) alertEl.innerHTML = '<div class="alert alert-error">เกิดข้อผิดพลาด</div>'; }

function resetRepairForm() {
  ['rf-type', 'rf-equip-code', 'rf-problem', 'rf-building', 'rf-dept', 'rf-room', 'rf-requester'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  const rfPriority = document.getElementById('rf-priority');
  if (rfPriority) rfPriority.value = 'normal';
  const rfImage = document.getElementById('rf-image');
  if (rfImage) rfImage.value = '';
  const equipInfoBox = document.getElementById('equip-info-box');
  if (equipInfoBox) {
    equipInfoBox.style.display = 'none';
    equipInfoBox.innerHTML = '<div style="font-size:13px;color:var(--text-muted);margin-bottom:4px;">ข้อมูลครุภัณฑ์ที่พบ</div><div id="equip-info-text" style="font-size:14px;font-weight:500;"></div>';
  }
  const partsSection = document.getElementById('parts-section');
  if (partsSection) partsSection.style.display = 'none';
  const repairAlert = document.getElementById('repair-alert');
  if (repairAlert) repairAlert.innerHTML = '';
  window.currentEquipId = null;
  window.currentEquipData = null;
}

// =============================================
// HISTORY
// =============================================
async function loadHistory() {
  if (!document.getElementById('hist-table')) return;
  const search = document.getElementById('hist-search')?.value || '';
  const status = document.getElementById('hist-status')?.value || '';
  const priority = document.getElementById('hist-priority')?.value || '';
  const dateFrom = document.getElementById('hist-date-start')?.value || '';
  const dateTo = document.getElementById('hist-date-end')?.value || '';
  let url = '/api/repairs?limit=100&';
  if (search) url += `search=${encodeURIComponent(search)}&`;
  if (status) url += `status=${status}&`;
  if (priority) url += `priority=${priority}&`;
  if (dateFrom) url += `date_from=${encodeURIComponent(dateFrom)}&`;
  if (dateTo) url += `date_to=${encodeURIComponent(dateTo)}&`;
  try {
    const res = await api('GET', url);
    const tbody = document.getElementById('hist-table');
    if (res.success && res.data.length) {
      tbody.innerHTML = res.data.map(r => `<tr><td style="font-family:'Space Mono';font-size:12px">${r.ticket_number}</td><td>${r.equipment_name}</td><td>${r.type_name}</td><td>${r.requester_name}</td><td style="font-size:12px">${formatDate(r.requested_at)}</td><td>${priorityBadge(r.priority)}</td><td>${statusBadge(r.status)}</td><td><button class="btn btn-outline btn-sm" onclick="openService(${r.id})">🛠️ ให้บริการ</button></td></tr>`).join('');
    } else { tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:32px">ไม่พบคำแจ้งซ่อม</td></tr>'; }
  } catch {}
}

// =============================================
// SERVICE
// =============================================
function openService(id) {
  window.location.href = `service.html?id=${id}`;
}

async function loadServiceData() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  if (!id) return;
  currentRepairId = id;
  try {
    const res = await api('GET', `/api/repairs/${id}`);
    if (!res.success) return;
    const r = res.data;
    const svcTicket = document.getElementById('svc-ticket');
    if (svcTicket) svcTicket.textContent = r.ticket_number;
    const svcStatus = document.getElementById('svc-status');
    if (svcStatus) svcStatus.value = r.status;

    const details = [
      ['ชื่อครุภัณฑ์', r.equipment_name],
      ['รหัสครุภัณฑ์', r.equipment_code],
      ['ประเภท', r.type_name],
      ['ชิ้นส่วนที่ซ่อม', r.equipment_parts || '-'],
      ['ปัญหาที่พบ', r.problem_description],
      ['ผู้แจ้ง', r.requester_name],
      ['สถานที่', `${r.location_building} / ${r.location_department} / ${r.location_room}`],
      ['ความเร่งด่วน', priorityBadge(r.priority)],
      ['วันที่แจ้ง', formatDate(r.requested_at)],
      ['สถานะ', statusBadge(r.status)],
      ['หมายเหตุ Admin', r.admin_note || '-'],
    ];
    const svcDetail = document.getElementById('svc-detail');
    if (svcDetail) svcDetail.innerHTML = details.map(([l, v]) => `<div class="detail-item"><label>${l}</label><span>${v}</span></div>`).join('');

    if (r.image_path) {
      const svcImg = document.getElementById('svc-img');
      if (svcImg) svcImg.src = r.image_path;
      const svcImgWrap = document.getElementById('svc-img-wrap');
      if (svcImgWrap) svcImgWrap.style.display = 'block';
    }

    const tl = document.getElementById('svc-timeline');
    if (tl && res.history) {
      tl.innerHTML = res.history.map(h => `<li><div class="timeline-time">${formatDate(h.changed_at)}</div><div class="timeline-text">${statusLabel(h.old_status)} → ${statusLabel(h.new_status)}</div>${h.note ? `<div class="timeline-note">หมายเหตุ: ${h.note}</div>` : ''}${h.admin_name ? `<div class="timeline-note">โดย: ${h.admin_name}</div>` : ''}</li>`).join('');
    }
  } catch (e) { console.error(e); }
}

async function updateStatus() {
  const status = document.getElementById('svc-status')?.value;
  const note = document.getElementById('svc-note')?.value;
  const alertEl = document.getElementById('svc-alert');

  if (!currentRepairId) {
    if (alertEl) alertEl.innerHTML = '<div class="alert alert-error">❌ ไม่พบรหัสคำแจ้งซ่อม</div>';
    return;
  }
  if (!status) {
    if (alertEl) alertEl.innerHTML = '<div class="alert alert-error">❌ กรุณาเลือกสถานะ</div>';
    return;
  }

  if (alertEl) alertEl.innerHTML = '<div class="alert alert-info">⏳ กำลังอัพเดตสถานะ...</div>';

  try {
    const res = await api('PATCH', `/api/repairs/${currentRepairId}/status`, { status, admin_note: note });
    if (res.success) {
      if (alertEl) alertEl.innerHTML = '<div class="alert alert-success">✅ อัพเดตสถานะสำเร็จ!</div>';
      setTimeout(() => {
        loadServiceData();
        const svcNote = document.getElementById('svc-note');
        if (svcNote) svcNote.value = '';
        setTimeout(() => { if (alertEl) alertEl.innerHTML = ''; }, 3000);
      }, 1000);
    } else {
      if (alertEl) alertEl.innerHTML = `<div class="alert alert-error">❌ ${res.message}</div>`;
    }
  } catch {
    if (alertEl) alertEl.innerHTML = '<div class="alert alert-error">❌ เกิดข้อผิดพลาดในการบันทึก</div>';
  }
}

// =============================================
// MODAL
// =============================================
function openModal(id) { const el = document.getElementById(id); if (el) el.classList.add('open'); }
function closeModal(id) { const el = document.getElementById(id); if (el) el.classList.remove('open'); }

// =============================================
// HELPERS
// =============================================
function showErr(el, msg) { el.textContent = msg; el.style.display = 'block'; }

function statusBadge(s) {
  const map = { pending: '⏳ รอดำเนินการ', in_progress: '🔄 ดำเนินการแล้ว', received: '📥 รับของแล้ว', sent_repair: '📦 ส่งซ่อม', completed: '✅ ซ่อมสำเร็จ', returned: '📤 ส่งคืนแล้ว', cancelled: '❌ ยกเลิก' };
  return `<span class="badge ${s}">${map[s] || s}</span>`;
}

function priorityBadge(p) {
  const map = { urgent: '🚨 เร่งด่วน', normal: '📋 ปกติ', low: '🔵 ไม่เร่งด่วน' };
  return `<span class="badge ${p}">${map[p] || p}</span>`;
}

function statusLabel(s) {
  const map = { pending: 'รอดำเนินการ', in_progress: 'ดำเนินการแล้ว', received: 'รับของแล้ว', sent_repair: 'ส่งซ่อม', completed: 'ซ่อมสำเร็จ', returned: 'ส่งคืนแล้ว', cancelled: 'ยกเลิก' };
  return map[s] || s || '-';
}

function formatDate(d) {
  if (!d) return '-';
  return new Date(d).toLocaleString('th-TH', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// =============================================
// TOAST NOTIFICATION
// =============================================
function showToast(message, type = 'success') {
  const oldToast = document.querySelector('.toast-custom');
  if (oldToast) oldToast.remove();

  const toast = document.createElement('div');
  toast.className = `toast-custom toast-${type}`;
  toast.textContent = message;
  const bgColor = type === 'success' ? '#22c55e' : type === 'error' ? '#ef4444' : '#3b82f6';
  toast.style.cssText = `
    position: fixed;
    bottom: 30px;
    right: 30px;
    padding: 14px 28px;
    background: ${bgColor};
    color: white;
    border-radius: 10px;
    z-index: 9999;
    font-size: 14px;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    animation: slideUp 0.4s ease;
    max-width: 400px;
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.4s ease';
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

// CSS animation
(function() {
  const styleSheet = document.createElement("style");
  styleSheet.textContent = `
    @keyframes slideUp {
      from { opacity: 0; transform: translateY(30px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(styleSheet);
})();

// =============================================
// EQUIPMENT MODAL
// =============================================
function openAddEquipModal() {
  document.getElementById('me-code').value = '';
  document.getElementById('me-name').value = '';
  document.getElementById('me-type').value = '';
  document.getElementById('me-building').value = '';
  document.getElementById('me-dept').value = '';
  document.getElementById('me-room').value = '';
  document.getElementById('equip-modal-alert').innerHTML = '';
  openModal('modal-equip');
}

// =============================================
// ROLE-BASED ACCESS CONTROL
// =============================================

function isAdmin() {
  return currentUser && currentUser.role === 'admin';
}

function isUser() {
  return currentUser && currentUser.role === 'user';
}

  const adminMenus = ['nav-dashboard', 'nav-equipment', 'nav-history', 'nav-user-management'];
  const userMenus = ['nav-type', 'nav-repair', 'nav-my-history'];

  if (isAdmin()) {
    adminMenus.forEach(menuId => {
      const el = document.getElementById(menuId);
      if (el) el.style.display = 'inline-flex';
    });
    userMenus.forEach(menuId => {
      const el = document.getElementById(menuId);
      if (el && !adminMenus.includes(menuId)) el.style.display = 'inline-flex';
    });
  } else {
    adminMenus.forEach(menuId => {
      const el = document.getElementById(menuId);
      if (el) el.style.display = 'none';
    });
    userMenus.forEach(menuId => {
      const el = document.getElementById(menuId);
      if (el) el.style.display = 'inline-flex';
    });
  }

  const currentPage = getCurrentPage();
  const adminOnlyPages = ['dashboard', 'user-management'];
  
  if (isAdmin()) return true;
  
  if (adminOnlyPages.includes(currentPage)) {
    window.location.href = 'my-history.html';
    return false;
  }
  
  return true;

function getCurrentPage() {
  const path = window.location.pathname;
  if (path.includes('dashboard')) return 'dashboard';
  if (path.includes('equipment')) return 'equipment';
  if (path.includes('user-management')) return 'user-management';
  if (path.includes('history')) return 'history';
  if (path.includes('my-history')) return 'my-history';
  if (path.includes('type-select')) return 'type-select';
  if (path.includes('repair-form')) return 'repair-form';
  if (path.includes('service')) return 'service';
  return 'unknown';
}

// =============================================
// MY HISTORY
// =============================================
async function loadMyHistory() {
  if (!document.getElementById('my-history-table')) return;
  
  const search = document.getElementById('hist-search')?.value || '';
  const status = document.getElementById('hist-status')?.value || '';
  let url = '/api/repairs?limit=100&';
  if (search) url += `search=${encodeURIComponent(search)}&`;
  if (status) url += `status=${status}`;
  
  try {
    const res = await api('GET', url);
    const tbody = document.getElementById('my-history-table');
    if (res.success && res.data.length) {
      tbody.innerHTML = res.data.map(r => `
        <tr>
          <td style="font-family:'Space Mono';font-size:12px">${r.ticket_number}</td>
          <td>${r.equipment_name}</td>
          <td>${r.type_name}</td>
          <td style="font-size:12px">${formatDate(r.requested_at)}</td>
          <td>${priorityBadge(r.priority)}</td>
          <td>${statusBadge(r.status)}</td>
          <td><button class="btn btn-outline btn-sm" onclick="openService(${r.id})">🔍 ดูรายละเอียด</button></td>
        </tr>
      `).join('');
    } else {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:32px">คุณยังไม่มีคำแจ้งซ่อม</td></tr>';
    }
  } catch {}
}

// =============================================
// DARK MODE
// =============================================
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
    updateThemeIcon('dark');
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
    updateThemeIcon('light');
  }

  const currentTheme = document.documentElement.getAttribute('data-theme');
  if (currentTheme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'light');
    localStorage.setItem('theme', 'light');
    updateThemeIcon('light');
  } else {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('theme', 'dark');
    updateThemeIcon('dark');
  }

function updateThemeIcon(theme) {
  const toggleBtn = document.getElementById('theme-toggle');
  if (toggleBtn) {
    toggleBtn.textContent = theme === 'dark' ? '☀️' : '🌙';
  }
}

document.addEventListener('DOMContentLoaded', initDarkMode);

// =============================================
// PROFILE FUNCTIONS
// =============================================
async function loadProfile() {
  try {
    const res = await api('GET', '/api/profile');
    if (res.success) {
      const user = res.data;
      document.getElementById('profile-username').value = user.username;
      document.getElementById('profile-fullname').value = user.full_name || '';
      document.getElementById('profile-email').value = user.email || '';
      document.getElementById('profile-phone').value = user.phone || '';
      
      // แสดงรูปโปรไฟล์
      if (user.avatar) {
        const imgEl = document.getElementById('avatar-img');
        const iconEl = document.getElementById('avatar-icon');
        if (imgEl && iconEl) {
          imgEl.src = user.avatar + '?t=' + Date.now();
          imgEl.style.display = 'block';
          iconEl.style.display = 'none';
        }
      }
    }
  } catch (error) {
    console.error('Error loading profile:', error);
  }
}

async function updateProfile() {
  const full_name = document.getElementById('profile-fullname').value.trim();
  const email = document.getElementById('profile-email').value.trim();
  const phone = document.getElementById('profile-phone').value.trim();
  const current_password = document.getElementById('profile-current-password').value;
  const new_password = document.getElementById('profile-new-password').value;
  const confirm_password = document.getElementById('profile-confirm-password').value;
  const alertEl = document.getElementById('profile-alert');
  
  if (!full_name) {
    alertEl.innerHTML = '<div class="alert alert-error">กรุณากรอกชื่อ-นามสกุล</div>';
    return;
  }
  
  if (new_password && new_password !== confirm_password) {
    alertEl.innerHTML = '<div class="alert alert-error">รหัสผ่านใหม่ไม่ตรงกัน</div>';
    return;
  }
  
  if (new_password && new_password.length < 4) {
    alertEl.innerHTML = '<div class="alert alert-error">รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร</div>';
    return;
  }
  
  const data = { full_name, email, phone };
  if (new_password) {
    if (!current_password) {
      alertEl.innerHTML = '<div class="alert alert-error">กรุณากรอกรหัสผ่านปัจจุบัน</div>';
      return;
    }
    data.current_password = current_password;
    data.new_password = new_password;
  }
  
  try {
    const res = await api('PUT', '/api/profile', data);
    if (res.success) {
      alertEl.innerHTML = '<div class="alert alert-success">✅ อัพเดตโปรไฟล์สำเร็จ</div>';
      setTimeout(() => alertEl.innerHTML = '', 3000);
      document.getElementById('topbar-uname').textContent = full_name;
      const user = JSON.parse(localStorage.getItem('repair_user') || '{}');
      user.full_name = full_name;
      localStorage.setItem('repair_user', JSON.stringify(user));
    } else {
      alertEl.innerHTML = `<div class="alert alert-error">❌ ${res.message}</div>`;
    }
  } catch (error) {
    alertEl.innerHTML = '<div class="alert alert-error">❌ เกิดข้อผิดพลาด กรุณาลองอีกครั้ง</div>';
  }
}

function resetProfileForm() {
  document.getElementById('profile-current-password').value = '';
  document.getElementById('profile-new-password').value = '';
  document.getElementById('profile-confirm-password').value = '';
  document.getElementById('profile-alert').innerHTML = '';
}

async function loadMyStats() {
  try {
    const res = await api('GET', '/api/repairs?limit=1000');
    if (res.success) {
      const repairs = res.data;
      const total = repairs.length;
      const pending = repairs.filter(r => r.status === 'pending').length;
      const completed = repairs.filter(r => r.status === 'completed').length;
      const totalCost = repairs.reduce((sum, r) => sum + (parseFloat(r.repair_cost) || 0), 0);
      
      const totalEl = document.getElementById('my-stat-total');
      const pendingEl = document.getElementById('my-stat-pending');
      const completedEl = document.getElementById('my-stat-completed');
      const costEl = document.getElementById('my-stat-cost');
      
      if (totalEl) totalEl.textContent = total;
      if (pendingEl) pendingEl.textContent = pending;
      if (completedEl) completedEl.textContent = completed;
      if (costEl) costEl.textContent = totalCost.toLocaleString();
    }
  } catch (error) {
    console.error('Error loading stats:', error);
  }
}

// Avatar Upload handler
document.getElementById('avatar-upload')?.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  
  const formData = new FormData();
  formData.append('avatar', file);
  
  try {
    const response = await fetch('/api/profile/avatar', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
      body: formData
    });
    const result = await response.json();
    if (result.success) {
      document.getElementById('avatar-img').src = result.avatar + '?t=' + Date.now();
      document.getElementById('avatar-img').style.display = 'block';
      document.getElementById('avatar-icon').style.display = 'none';
      showToast('อัพโหลดรูปโปรไฟล์สำเร็จ', 'success');
    }
  } catch (error) {
    showToast('อัพโหลดรูปโปรไฟล์ล้มเหลว', 'error');
  }
});

// =============================================
// USER MANAGEMENT FUNCTIONS
// =============================================

async function loadUsers() {
  const search = document.getElementById('user-search')?.value || '';
  let url = '/api/users?';
  if (search) url += `search=${encodeURIComponent(search)}`;
  
  try {
    const res = await api('GET', url);
    const tbody = document.getElementById('user-table');
    if (res.success && res.data.length) {
      tbody.innerHTML = res.data.map(u => `
        <tr>
          <td>${u.id}</td>
          <td><strong>${u.username}</strong></td>
          <td>${u.full_name || '-'}</td>
          <td>${u.email || '-'}</td>
          <td>${u.phone || '-'}</td>
          <td>${u.role === 'admin' ? '👑 Admin' : '👤 User'}</td>
          <td style="font-size:12px">${formatDate(u.created_at)}</td>
          <td>${u.status === 'active' ? '<span class="badge success">✅ ใช้งาน</span>' : '<span class="badge cancelled">⛔ ปิดใช้งาน</span>'}</td>
          <td>
            <button class="btn btn-outline btn-sm" onclick="openEditUserModal(${u.id})" style="margin-right:5px;">✏️ แก้ไข</button>
            <button class="btn btn-danger btn-sm" onclick="deleteUser(${u.id}, '${u.username}')">🗑️ ลบ</button>
          </td>
        </tr>
      `).join('');
    } else {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:40px;">ไม่พบข้อมูลผู้ใช้</td></tr>';
    }
  } catch (error) {
    console.error('Error loading users:', error);
  }
}

function openAddUserModal() {
  document.getElementById('add-user-alert').innerHTML = '';
  document.getElementById('add-username').value = '';
  document.getElementById('add-fullname').value = '';
  document.getElementById('add-email').value = '';
  document.getElementById('add-phone').value = '';
  document.getElementById('add-password').value = '';
  document.getElementById('add-confirm-password').value = '';
  document.getElementById('add-role').value = 'user';
  openModal('modal-add-user');
}

async function addUser() {
  const username = document.getElementById('add-username').value.trim();
  const full_name = document.getElementById('add-fullname').value.trim();
  const email = document.getElementById('add-email').value.trim();
  const phone = document.getElementById('add-phone').value.trim();
  const password = document.getElementById('add-password').value;
  const confirmPassword = document.getElementById('add-confirm-password').value;
  const role = document.getElementById('add-role').value;
  const alertEl = document.getElementById('add-user-alert');
  
  if (!username) {
    alertEl.innerHTML = '<div class="alert alert-error">กรุณากรอกชื่อผู้ใช้</div>';
    return;
  }
  if (!full_name) {
    alertEl.innerHTML = '<div class="alert alert-error">กรุณากรอกชื่อ-นามสกุล</div>';
    return;
  }
  if (!password) {
    alertEl.innerHTML = '<div class="alert alert-error">กรุณากรอกรหัสผ่าน</div>';
    return;
  }
  if (password.length < 4) {
    alertEl.innerHTML = '<div class="alert alert-error">รหัสผ่านต้องมีความยาวอย่างน้อย 4 ตัวอักษร</div>';
    return;
  }
  if (password !== confirmPassword) {
    alertEl.innerHTML = '<div class="alert alert-error">รหัสผ่านไม่ตรงกัน</div>';
    return;
  }
  
  try {
    const res = await api('POST', '/api/users', { username, full_name, email, phone, password, role });
    if (res.success) {
      closeModal('modal-add-user');
      loadUsers();
      showToast('เพิ่มผู้ใช้สำเร็จ', 'success');
    } else {
      alertEl.innerHTML = `<div class="alert alert-error">${res.message}</div>`;
    }
  } catch (error) {
    console.error('Add user error:', error);
    alertEl.innerHTML = '<div class="alert alert-error">เกิดข้อผิดพลาด กรุณาลองอีกครั้ง</div>';
  }
}

async function openEditUserModal(id) {
  try {
    const res = await api('GET', `/api/users/${id}`);
    if (res.success) {
      const user = res.data;
      document.getElementById('edit-user-id').value = user.id;
      document.getElementById('edit-username').value = user.username;
      document.getElementById('edit-fullname').value = user.full_name || '';
      document.getElementById('edit-email').value = user.email || '';
      document.getElementById('edit-phone').value = user.phone || '';
      document.getElementById('edit-role').value = user.role;
      document.getElementById('edit-status').value = user.status || 'active';
      document.getElementById('edit-password').value = '';
      document.getElementById('edit-user-alert').innerHTML = '';
      openModal('modal-edit-user');
    } else {
      showToast('ไม่พบข้อมูลผู้ใช้', 'error');
    }
  } catch (error) {
    console.error('Edit user error:', error);
    showToast('เกิดข้อผิดพลาดในการโหลดข้อมูล', 'error');
  }
}

async function updateUser() {
  const id = document.getElementById('edit-user-id').value;
  const full_name = document.getElementById('edit-fullname').value;
  const email = document.getElementById('edit-email').value;
  const phone = document.getElementById('edit-phone').value;
  const role = document.getElementById('edit-role').value;
  const status = document.getElementById('edit-status').value;
  const password = document.getElementById('edit-password').value;
  const alertEl = document.getElementById('edit-user-alert');
  
  try {
    const data = { full_name, email, phone, role, status };
    if (password && password.trim()) {
      if (password.length < 4) {
        alertEl.innerHTML = '<div class="alert alert-error">รหัสผ่านต้องมีความยาวอย่างน้อย 4 ตัวอักษร</div>';
        return;
      }
      data.password = password;
    }
    
    const res = await api('PUT', `/api/users/${id}`, data);
    if (res.success) {
      closeModal('modal-edit-user');
      loadUsers();
      showToast('อัพเดตผู้ใช้สำเร็จ', 'success');
    } else {
      alertEl.innerHTML = `<div class="alert alert-error">${res.message}</div>`;
    }
  } catch (error) {
    console.error('Update user error:', error);
    alertEl.innerHTML = '<div class="alert alert-error">เกิดข้อผิดพลาด กรุณาลองอีกครั้ง</div>';
  }
}

async function deleteUser(id, username) {
  if (!confirm(`ต้องการลบผู้ใช้ "${username}" ออกจากระบบใช่หรือไม่?`)) return;
  
  try {
    const res = await api('DELETE', `/api/users/${id}`);
    if (res.success) {
      loadUsers();
      showToast('ลบผู้ใช้สำเร็จ', 'success');
    } else {
      showToast(res.message, 'error');
    }
  } catch (error) {
    console.error('Delete user error:', error);
    showToast('เกิดข้อผิดพลาด กรุณาลองอีกครั้ง', 'error');
  }
}

// แก้ไขฟังก์ชัน loadHistory()

// =============================================
// ฟังก์ชันลบคำร้องขอซ่อม (แก้ไข)
// =============================================

async function deleteRepair(id, ticketNumber) {
  // ตรวจสอบว่าผู้ใช้เป็น Admin หรือไม่
  const user = JSON.parse(localStorage.getItem('repair_user') || 'null');
  if (!user || user.role !== 'admin') {
    alert('⚠️ เฉพาะ Admin เท่านั้นที่สามารถลบคำร้องขอซ่อมได้');
    return;
  }

  const response = await fetch(url, {
    ...options,
    headers
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `HTTP error ${response.status}`);
  }

  return response.json();
}
// ===== Notification Polling (ทุก 5 วินาที) =====
(function() {
  var lastCount = 0;
  function poll() {
    if (!token || !currentUser) return;
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/api/notifications');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onload = function() {
      try {
        var r = JSON.parse(xhr.responseText);
        if (r.success) {
          var badge = document.getElementById('notif-badge');
          if (badge) {
            badge.textContent = r.unread;
            badge.style.display = r.unread > 0 ? 'inline-flex' : 'none';
          }
          if (r.unread > lastCount && lastCount > 0) {
            showToast('🔔 มี ' + (r.unread - lastCount) + ' การแจ้งเตือนใหม่!', 'info');
          }
          lastCount = r.unread;
        }
      } catch(e) {}
    };
    xhr.send();
  }
  setTimeout(poll, 2000);
  setInterval(poll, 5000);
})();

