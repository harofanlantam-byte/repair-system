// =============================================
// ระบบเว็บแจ้งซ่อม - Backend Server (Node.js + Express)
// รองรับ Role-Based Access Control (Admin / User / Manager)
// =============================================

require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const cors = require('cors');
const fs = require('fs');
const XLSX = require('xlsx');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'repair_system_secret_key_2024';

// Security Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());

// Rate Limiting - ป้องกัน Brute-force Login
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 นาที
    max: 10, // 10 ครั้งต่อ IP
    message: { success: false, message: 'ลองเข้าสู่ระบบบ่อยเกินไป กรุณารอ 15 นาที' }
});
app.use('/api/auth/login', loginLimiter);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(__dirname));

// สร้างโฟลเดอร์ uploads ถ้ายังไม่มี
if (!fs.existsSync('./uploads')) fs.mkdirSync('./uploads');
if (!fs.existsSync('./backups')) fs.mkdirSync('./backups');

// =============================================
// Database Connection
// =============================================
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '',
    database: process.env.DB_NAME || 'repair_system',
    charset: 'utf8mb4',
    connectTimeout: 10000 // 10 seconds timeout
};

let db;
async function connectDB() {
    try {
        console.log('⏳ กำลังเชื่อมต่อฐานข้อมูล MySQL...');
        db = await mysql.createConnection(dbConfig);
        console.log('✅ เชื่อมต่อฐานข้อมูล MySQL สำเร็จ');
    } catch (err) {
        console.error('❌ ไม่สามารถเชื่อมต่อฐานข้อมูล:', err.message);
        console.error('💡 กรุณาตรวจสอบว่า XAMPP MySQL ทำงานอยู่และฐานข้อมูล repair_system มีอยู่');
        console.error('💡 รัน SQL จาก schema.sql เพื่อสร้างฐานข้อมูล');
        process.exit(1);
    }
}

// =============================================
// Multer - อัพโหลดรูปภาพ
// =============================================
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, './uploads/'),
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
        cb(null, unique + path.extname(file.originalname));
    }
});
const upload = multer({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const allowed = /jpeg|jpg|png|gif|webp/;
        const ext = allowed.test(path.extname(file.originalname).toLowerCase());
        const mime = allowed.test(file.mimetype);
        if (ext && mime) cb(null, true);
        else cb(new Error('อนุญาตเฉพาะไฟล์รูปภาพเท่านั้น'));
    }
});

// =============================================
// Auth & RBAC Middleware
// =============================================
function authMiddleware(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ success: false, message: 'กรุณาเข้าสู่ระบบ' });
    try {
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch {
        res.status(401).json({ success: false, message: 'Token ไม่ถูกต้องหรือหมดอายุ' });
    }
}

function adminMiddleware(req, res, next) {
    if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'ไม่มีสิทธิ์เข้าถึง (Admin เท่านั้น)' });
    }
    next();
}

function managerMiddleware(req, res, next) {
    if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'manager')) {
        return res.status(403).json({ success: false, message: 'ไม่มีสิทธิ์เข้าถึง (Manager/Admin เท่านั้น)' });
    }
    next();
}


// สร้างหมายเลขตั๋ว
function generateTicketNumber() {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    const rand = Math.floor(Math.random() * 9000) + 1000;
    return `REP-${y}${m}${d}-${rand}`;
}

function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401); // ถ้าไม่มี Token ส่งกลับ 401

    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
        if (err) return res.sendStatus(403); // ถ้า Token ไม่ถูกต้อง ส่งกลับ 403
        req.user = user;
        next(); // ผ่านเงื่อนไข ไปทำงานที่ Router ต่อได้
    });
}

// =============================================
// Audit Log Helper
// =============================================
async function addAuditLog(userId, username, action, details, ipAddress) {
    try {
        await db.query(
            'INSERT INTO audit_logs (user_id, username, action, details, ip_address) VALUES (?, ?, ?, ?, ?)',
            [userId || null, username || null, action, details || null, ipAddress || null]
        );
    } catch (err) {
        console.error('Audit log error:', err.message);
    }
}

// =============================================
// Routes: Authentication
// =============================================

// POST /api/auth/login
app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password)
        return res.status(400).json({ success: false, message: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน' });
    try {
        const [rows] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
        if (!rows.length)
            return res.status(401).json({ success: false, message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
        const user = rows[0];
        const valid = await bcrypt.compare(password, user.password);
        if (!valid)
            return res.status(401).json({ success: false, message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
        const token = jwt.sign({ id: user.id, username: user.username, role: user.role, full_name: user.full_name }, JWT_SECRET, { expiresIn: '8h' });
        res.json({ success: true, token, user: { id: user.id, username: user.username, role: user.role, full_name: user.full_name } });
    } catch (err) {
        res.status(500).json({ success: false, message: 'เกิดข้อผิดพลาด: ' + err.message });
    }
});

// POST /api/auth/register
app.post('/api/auth/register', async (req, res) => {
    const { username, password, full_name, email, phone } = req.body;
    if (!username || !password || !full_name || !email)
        return res.status(400).json({ success: false, message: 'กรุณากรอกข้อมูลให้ครบ (ชื่อผู้ใช้, รหัสผ่าน, ชื่อ-นามสกุล, อีเมล)' });
    if (password.length < 6)
        return res.status(400).json({ success: false, message: 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร' });
    try {
        const [existing] = await db.query('SELECT id FROM users WHERE username = ?', [username]);
        if (existing.length)
            return res.status(409).json({ success: false, message: 'ชื่อผู้ใช้นี้มีอยู่แล้ว' });
        const hashed = await bcrypt.hash(password, 10);
        await db.query(
            'INSERT INTO users (username, password, full_name, email, phone, role, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [username, hashed, full_name, email || null, phone || null, 'user', 'active']
        );
        res.json({ success: true, message: 'ลงทะเบียนสำเร็จ กรุณาเข้าสู่ระบบ' });
    } catch (err) {
        res.status(500).json({ success: false, message: 'เกิดข้อผิดพลาด: ' + err.message });
    }
});

// =============================================
// Routes: Dashboard Stats (Admin เท่านั้น)
// =============================================

app.get('/api/dashboard/stats', authMiddleware, adminMiddleware, async (req, res) => {
    const { date_from, date_to } = req.query;
    const dateFilter = [];
    const dateParams = [];

    if (date_from) {
        dateFilter.push('requested_at >= ?');
        dateParams.push(date_from + ' 00:00:00');
    }
    if (date_to) {
        dateFilter.push('requested_at <= ?');
        dateParams.push(date_to + ' 23:59:59');
    }
    const dateWhere = dateFilter.length ? ' AND ' + dateFilter.join(' AND ') : '';

    try {
        const [totalRows] = await db.query(`SELECT COUNT(*) as total FROM repair_requests WHERE 1=1${dateWhere}`, dateParams);
        const [pendingRows] = await db.query(`SELECT COUNT(*) as pending FROM repair_requests WHERE status='pending'${dateWhere}`, dateParams);
        const [inProgressRows] = await db.query(`SELECT COUNT(*) as in_progress FROM repair_requests WHERE status='in_progress'${dateWhere}`, dateParams);
        const [sentRepairRows] = await db.query(`SELECT COUNT(*) as sent_repair FROM repair_requests WHERE status='sent_repair'${dateWhere}`, dateParams);
        const [completedRows] = await db.query(`SELECT COUNT(*) as completed FROM repair_requests WHERE status='completed'${dateWhere}`, dateParams);
        const [urgentRows] = await db.query(`SELECT COUNT(*) as urgent FROM repair_requests WHERE priority='urgent' AND status != 'completed'${dateWhere}`, dateParams);

        const total = totalRows[0]?.total || 0;
        const pending = pendingRows[0]?.pending || 0;
        const in_progress = inProgressRows[0]?.in_progress || 0;
        const sent_repair = sentRepairRows[0]?.sent_repair || 0;
        const completed = completedRows[0]?.completed || 0;
        const urgent = urgentRows[0]?.urgent || 0;

        const [monthly] = await db.query(`
            SELECT DATE_FORMAT(requested_at, '%Y-%m') as month, COUNT(*) as count
            FROM repair_requests
            WHERE (requested_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH))
            ${dateFilter.length ? ' AND ' + dateFilter.join(' AND ') : ''}
            GROUP BY month ORDER BY month
        `, dateParams);

        const [byType] = await db.query(`
            SELECT et.name, COUNT(rr.id) as count
            FROM repair_requests rr
            JOIN equipment e ON rr.equipment_id = e.id
            JOIN equipment_types et ON e.equipment_type_id = et.id
            WHERE 1=1${dateWhere}
            GROUP BY et.name
        `, dateParams);

        res.json({ success: true, stats: { total, pending, in_progress, sent_repair, completed, urgent }, monthly, byType });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// Routes: Equipment Types (ประเภทครุภัณฑ์)
// =============================================

// GET /api/equipment-types - รายการประเภททั้งหมด (รวม parts)
app.get('/api/equipment-types', authMiddleware, async (req, res) => {
    try {
        const [types] = await db.query('SELECT * FROM equipment_types ORDER BY name');
        for (let type of types) {
            const [parts] = await db.query('SELECT * FROM equipment_parts WHERE equipment_type_id = ?', [type.id]);
            type.parts = parts;
        }
        res.json({ success: true, data: types });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// Routes: Equipment (ครุภัณฑ์)
// =============================================

// GET /api/equipment - ทุกคนดูได้
app.get('/api/equipment', authMiddleware, async (req, res) => {
    const { type_id, search } = req.query;
    let sql = `SELECT e.*, et.name as type_name FROM equipment e JOIN equipment_types et ON e.equipment_type_id = et.id WHERE e.status = 'active'`;
    const params = [];
    if (type_id) { sql += ' AND e.equipment_type_id = ?'; params.push(type_id); }
    if (search) { sql += ' AND (e.equipment_code LIKE ? OR e.equipment_name LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    sql += ' ORDER BY e.created_at DESC';
    try {
        const [rows] = await db.query(sql, params);
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// POST /api/equipment - เฉพาะ Admin
app.post('/api/equipment', authMiddleware, adminMiddleware, async (req, res) => {
    const { equipment_code, equipment_name, equipment_type_id, location_building, location_department, location_room } = req.body;
    if (!equipment_code || !equipment_name || !equipment_type_id)
        return res.status(400).json({ success: false, message: 'กรุณากรอกข้อมูลที่จำเป็น' });
    try {
        const [existing] = await db.query('SELECT id FROM equipment WHERE equipment_code = ?', [equipment_code]);
        if (existing.length)
            return res.status(409).json({ success: false, message: 'รหัสครุภัณฑ์นี้มีอยู่แล้ว' });
        await db.query(
            'INSERT INTO equipment (equipment_code, equipment_name, equipment_type_id, location_building, location_department, location_room) VALUES (?, ?, ?, ?, ?, ?)',
            [equipment_code, equipment_name, equipment_type_id, location_building, location_department, location_room]
        );
        await addAuditLog(req.user.id, req.user.username, 'เพิ่มครุภัณฑ์', `รหัส: ${equipment_code}, ชื่อ: ${equipment_name}`, req.ip);
        res.json({ success: true, message: 'เพิ่มครุภัณฑ์สำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// PUT /api/equipment/:id - แก้ไขครุภัณฑ์ (Admin เท่านั้น)
app.put('/api/equipment/:id', authMiddleware, adminMiddleware, async (req, res) => {
    const { equipment_code, equipment_name, equipment_type_id, location_building, location_department, location_room } = req.body;
    try {
        await db.query(
            `UPDATE equipment SET equipment_code=?, equipment_name=?, equipment_type_id=?, location_building=?, location_department=?, location_room=? WHERE id=?`,
            [equipment_code, equipment_name, equipment_type_id, location_building, location_department, location_room, req.params.id]
        );
        await addAuditLog(req.user.id, req.user.username, 'แก้ไขครุภัณฑ์', `id=${req.params.id}, รหัส: ${equipment_code}`, req.ip);
        res.json({ success: true, message: 'อัพเดตครุภัณฑ์สำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// GET /api/equipment/:id - ดึงครุภัณฑ์ตาม ID (ต้องมาก่อน DELETE)
app.get('/api/equipment/:id', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT e.*, et.name as type_name, et.has_parts FROM equipment e
             JOIN equipment_types et ON e.equipment_type_id = et.id
             WHERE e.id = ?`,
            [req.params.id]
        );
        if (!rows.length)
            return res.status(404).json({ success: false, message: 'ไม่พบครุภัณฑ์' });
        res.json({ success: true, data: rows[0] });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// DELETE /api/equipment/:id - เฉพาะ Admin
app.delete('/api/equipment/:id', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        await db.query('UPDATE equipment SET status = ? WHERE id = ?', ['inactive', req.params.id]);
        res.json({ success: true, message: 'ลบครุภัณฑ์สำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// GET /api/equipment/code/:code - ทุกคนใช้ได้
app.get('/api/equipment/code/:code', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT e.*, et.name as type_name, et.has_parts FROM equipment e
             JOIN equipment_types et ON e.equipment_type_id = et.id
             WHERE e.equipment_code = ? AND e.status = 'active'`,
            [req.params.code]
        );
        if (!rows.length)
            return res.status(404).json({ success: false, message: 'ไม่พบครุภัณฑ์นี้ในระบบ' });
        const eq = rows[0];
        if (eq.has_parts) {
            const [parts] = await db.query('SELECT * FROM equipment_parts WHERE equipment_type_id = ?', [eq.equipment_type_id]);
            eq.parts = parts;
        }
        res.json({ success: true, data: eq });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// Routes: Repair Requests (คำแจ้งซ่อม)
// =============================================

// POST /api/repairs - ทุกคนสร้างได้
app.post('/api/repairs', authMiddleware, upload.single('image'), async (req, res) => {
    const { equipment_id, equipment_parts, problem_description, requester_name, location_building, location_department, location_room, priority } = req.body;
    if (!equipment_id || !problem_description || !requester_name)
        return res.status(400).json({ success: false, message: 'กรุณากรอกข้อมูลที่จำเป็น' });
    try {
        const ticket = generateTicketNumber();
        const image_path = req.file ? `/uploads/${req.file.filename}` : null;
        await db.query(
            `INSERT INTO repair_requests (ticket_number, equipment_id, equipment_parts, problem_description, requester_name, location_building, location_department, location_room, priority, image_path, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
            [ticket, equipment_id, equipment_parts || null, problem_description, requester_name, location_building, location_department, location_room, priority || 'normal', image_path]
        );
        const [newReq] = await db.query('SELECT id FROM repair_requests WHERE ticket_number = ?', [ticket]);
        await db.query(
            'INSERT INTO status_history (repair_request_id, old_status, new_status, note) VALUES (?, ?, ?, ?)',
            [newReq[0].id, null, 'pending', 'สร้างคำแจ้งซ่อมใหม่']
        );
        res.json({ success: true, message: 'บันทึกคำแจ้งซ่อมสำเร็จ', ticket_number: ticket });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// GET /api/repairs - Admin เห็นทั้งหมด, User เห็นเฉพาะของตัวเอง
app.get('/api/repairs', authMiddleware, async (req, res) => {
    const { status, priority, search, date_from, date_to, limit = 50, offset = 0 } = req.query;
    let sql = `SELECT rr.*, e.equipment_code, e.equipment_name, et.name as type_name
               FROM repair_requests rr
               JOIN equipment e ON rr.equipment_id = e.id
               JOIN equipment_types et ON e.equipment_type_id = et.id
               WHERE 1=1`;
    const params = [];

    // User เห็นเฉพาะที่ตัวเองแจ้ง
    if (req.user.role !== 'admin') {
        sql += ' AND rr.requester_name = ?';
        params.push(req.user.full_name);
    }

    if (status) { sql += ' AND rr.status = ?'; params.push(status); }
    if (priority) { sql += ' AND rr.priority = ?'; params.push(priority); }
    if (search) { sql += ' AND (rr.ticket_number LIKE ? OR rr.requester_name LIKE ? OR e.equipment_code LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
    if (date_from) { sql += ' AND rr.requested_at >= ?'; params.push(date_from + ' 00:00:00'); }
    if (date_to) { sql += ' AND rr.requested_at <= ?'; params.push(date_to + ' 23:59:59'); }
    sql += ' ORDER BY rr.requested_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    try {
        const [rows] = await db.query(sql, params);

        // Count query (with same filters)
        let countSql = 'SELECT COUNT(*) as count FROM repair_requests WHERE 1=1';
        const countParams = [];
        if (req.user.role !== 'admin') {
            countSql += ' AND requester_name = ?';
            countParams.push(req.user.full_name);
        }
        if (status) { countSql += ' AND status = ?'; countParams.push(status); }
        if (priority) { countSql += ' AND priority = ?'; countParams.push(priority); }
        if (search) { countSql += ' AND (ticket_number LIKE ? OR requester_name LIKE ?)'; countParams.push(`%${search}%`, `%${search}%`); }
        if (date_from) { countSql += ' AND requested_at >= ?'; countParams.push(date_from + ' 00:00:00'); }
        if (date_to) { countSql += ' AND requested_at <= ?'; countParams.push(date_to + ' 23:59:59'); }
        const [countRows] = await db.query(countSql, countParams);

        res.json({ success: true, data: rows, total: countRows[0]?.count || 0 });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// GET /api/repairs/:id - ดูรายละเอียดคำแจ้งซ่อม
app.get('/api/repairs/:id', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT rr.*, e.equipment_code, e.equipment_name, et.name as type_name
             FROM repair_requests rr
             JOIN equipment e ON rr.equipment_id = e.id
             JOIN equipment_types et ON e.equipment_type_id = et.id
             WHERE rr.id = ?`,
            [req.params.id]
        );
        if (!rows.length)
            return res.status(404).json({ success: false, message: 'ไม่พบคำแจ้งซ่อม' });
        const [history] = await db.query(
            `SELECT sh.*, u.full_name as admin_name FROM status_history sh
             LEFT JOIN users u ON sh.changed_by = u.id
             WHERE sh.repair_request_id = ? ORDER BY sh.changed_at ASC`,
            [req.params.id]
        );
        res.json({ success: true, data: rows[0], history });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// PATCH /api/repairs/:id/status - เฉพาะ Admin
app.patch('/api/repairs/:id/status', authMiddleware, adminMiddleware, async (req, res) => {
    const { status, admin_note } = req.body;
    const repairId = req.params.id;

    const validStatuses = ['pending', 'in_progress', 'received', 'sent_repair', 'completed', 'returned', 'cancelled'];

    if (!status) return res.status(400).json({ success: false, message: 'กรุณาระบุสถานะ' });
    if (!validStatuses.includes(status)) return res.status(400).json({ success: false, message: 'สถานะไม่ถูกต้อง' });

    try {
        const [rows] = await db.query('SELECT status FROM repair_requests WHERE id = ?', [repairId]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'ไม่พบคำแจ้งซ่อม' });

        const oldStatus = rows[0].status;
        const completedAt = status === 'completed' ? new Date() : null;

        await db.query(
            'UPDATE repair_requests SET status = ?, admin_note = ?, completed_at = ?, updated_at = NOW() WHERE id = ?',
            [status, admin_note || null, completedAt, repairId]
        );
        await db.query(
            'INSERT INTO status_history (repair_request_id, old_status, new_status, changed_by, note) VALUES (?, ?, ?, ?, ?)',
            [repairId, oldStatus, status, req.user.id, admin_note || null]
        );

        res.json({ success: true, message: 'อัพเดตสถานะสำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// Routes: User Management (Admin เท่านั้น)
// =============================================

// GET /api/users
app.get('/api/users', authMiddleware, adminMiddleware, async (req, res) => {
    const { search } = req.query;
    let sql = 'SELECT id, username, full_name, role, created_at, status FROM users WHERE username != "admin"';
    const params = [];
    if (search) {
        sql += ' AND (username LIKE ? OR full_name LIKE ?)';
        params.push(`%${search}%`, `%${search}%`);
    }
    sql += ' ORDER BY created_at DESC';
    try {
        const [rows] = await db.query(sql, params);
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// GET /api/users/:id
app.get('/api/users/:id', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const [rows] = await db.query('SELECT id, username, full_name, role, created_at, status FROM users WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'ไม่พบผู้ใช้' });
        res.json({ success: true, data: rows[0] });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// PUT /api/users/:id
app.put('/api/users/:id', authMiddleware, adminMiddleware, async (req, res) => {
    const { full_name, role, password } = req.body;
    try {
        let sql = 'UPDATE users SET full_name = ?, role = ?';
        const params = [full_name, role];
        if (password && password.trim()) {
            const hashed = await bcrypt.hash(password, 10);
            sql += ', password = ?';
            params.push(hashed);
        }
        sql += ' WHERE id = ?';
        params.push(req.params.id);
        await db.query(sql, params);
        res.json({ success: true, message: 'อัพเดตผู้ใช้สำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// PATCH /api/users/:id/status
app.patch('/api/users/:id/status', authMiddleware, adminMiddleware, async (req, res) => {
    const { status } = req.body;
    try {
        await db.query('UPDATE users SET status = ? WHERE id = ?', [status, req.params.id]);
        res.json({ success: true, message: 'อัพเดตสถานะสำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// Profile Routes
// =============================================

// GET /api/profile
app.get('/api/profile', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT id, username, full_name, email, phone, avatar, role, created_at FROM users WHERE id = ?',
            [req.user.id]
        );
        if (!rows.length) {
            return res.status(404).json({ success: false, message: 'ไม่พบผู้ใช้' });
        }
        res.json({ success: true, data: rows[0] });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// PUT /api/profile
app.put('/api/profile', authMiddleware, async (req, res) => {
    const { full_name, email, phone, current_password, new_password } = req.body;
    
    try {
        // ถ้ามีการเปลี่ยนรหัสผ่าน
        if (new_password) {
            const [user] = await db.query('SELECT password FROM users WHERE id = ?', [req.user.id]);
            const valid = await bcrypt.compare(current_password, user[0].password);
            if (!valid) {
                return res.status(401).json({ success: false, message: 'รหัสผ่านปัจจุบันไม่ถูกต้อง' });
            }
            const hashed = await bcrypt.hash(new_password, 10);
            await db.query(
                'UPDATE users SET full_name = ?, email = ?, phone = ?, password = ? WHERE id = ?',
                [full_name, email, phone, hashed, req.user.id]
            );
        } else {
            await db.query(
                'UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?',
                [full_name, email, phone, req.user.id]
            );
        }
        
        res.json({ success: true, message: 'อัพเดตโปรไฟล์สำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// Avatar Upload
// =============================================
const avatarStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const avatarsDir = './uploads/avatars';
        if (!fs.existsSync(avatarsDir)) {
            fs.mkdirSync(avatarsDir, { recursive: true });
        }
        cb(null, avatarsDir);
    },
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + req.user.id;
        const ext = path.extname(file.originalname).toLowerCase();
        cb(null, unique + ext);
    }
});

const avatarUpload = multer({ 
    storage: avatarStorage, 
    limits: { fileSize: 2 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const allowed = /jpeg|jpg|png|gif|webp/;
        const ext = allowed.test(path.extname(file.originalname).toLowerCase());
        const mime = allowed.test(file.mimetype);
        if (ext && mime) {
            cb(null, true);
        } else {
            cb(new Error('อนุญาตเฉพาะไฟล์รูปภาพ (JPG, PNG, GIF, WEBP) เท่านั้น'));
        }
    }
});

app.post('/api/profile/avatar', authMiddleware, (req, res) => {
    avatarUpload.single('avatar')(req, res, async (err) => {
        if (err) {
            console.error('Avatar upload error:', err.message);
            return res.status(400).json({ success: false, message: err.message });
        }
        
        if (!req.file) {
            return res.status(400).json({ success: false, message: 'กรุณาเลือกไฟล์รูปภาพ' });
        }
        
        try {
            const avatar_path = `/uploads/avatars/${req.file.filename}`;
            
            const [oldUser] = await db.query('SELECT avatar FROM users WHERE id = ?', [req.user.id]);
            if (oldUser[0]?.avatar && oldUser[0].avatar !== avatar_path) {
                const oldPath = '.' + oldUser[0].avatar;
                if (fs.existsSync(oldPath)) {
                    fs.unlinkSync(oldPath);
                }
            }
            
            await db.query('UPDATE users SET avatar = ? WHERE id = ?', [avatar_path, req.user.id]);
            res.json({ success: true, avatar: avatar_path });
        } catch (error) {
            console.error('Database error:', error);
            res.status(500).json({ success: false, message: 'เกิดข้อผิดพลาดในการบันทึก' });
        }
    });
});

// =============================================
// Repair Cost Routes
// =============================================

// PUT /api/repairs/:id/cost - บันทึกค่าใช้จ่าย (เฉพาะ Admin)
app.put('/api/repairs/:id/cost', authMiddleware, async (req, res) => {
    // ตรวจสอบว่าเป็น Admin
    if (req.user.role !== 'admin') {
        return res.status(403).json({ 
            success: false, 
            message: 'คุณไม่มีสิทธิ์เข้าถึง (ต้องเป็น Admin เท่านั้น)' 
        });
    }
    
    const { repair_cost, cost_note } = req.body;
    const repairId = req.params.id;
    
    console.log('Saving repair cost:');
    console.log('ID:', repairId);
    console.log('Cost:', repair_cost);
    console.log('Note:', cost_note);
    
    // ตรวจสอบค่าใช้จ่าย
    if (repair_cost === undefined || repair_cost === null) {
        return res.status(400).json({ 
            success: false, 
            message: 'กรุณาระบุค่าใช้จ่าย' 
        });
    }
    
    if (isNaN(parseFloat(repair_cost)) || parseFloat(repair_cost) < 0) {
        return res.status(400).json({ 
            success: false, 
            message: 'ค่าใช้จ่ายต้องเป็นตัวเลขที่มากกว่า 0' 
        });
    }
    
    try {
        // ตรวจสอบว่ามีคำแจ้งซ่อมนี้หรือไม่
        const [rows] = await db.query('SELECT id FROM repair_requests WHERE id = ?', [repairId]);
        if (!rows.length) {
            return res.status(404).json({ 
                success: false, 
                message: 'ไม่พบคำแจ้งซ่อม' 
            });
        }
        
        // อัพเดตค่าใช้จ่าย
        await db.query(
            'UPDATE repair_requests SET repair_cost = ?, cost_note = ? WHERE id = ?',
            [parseFloat(repair_cost), cost_note || null, repairId]
        );
        
        console.log('✅ Cost saved successfully');
        res.json({ 
            success: true, 
            message: 'บันทึกค่าใช้จ่ายสำเร็จ',
            repair_cost: parseFloat(repair_cost),
            cost_note: cost_note || ''
        });
        
    } catch (err) {
        console.error('Error saving cost:', err);
        res.status(500).json({ 
            success: false, 
            message: 'เกิดข้อผิดพลาด: ' + err.message 
        });
    }
});

// GET /api/repairs/:id/cost - ดึงข้อมูลค่าใช้จ่าย
app.get('/api/repairs/:id/cost', authMiddleware, async (req, res) => {
    const repairId = req.params.id;
    
    try {
        const [rows] = await db.query(
            'SELECT repair_cost, cost_note FROM repair_requests WHERE id = ?',
            [repairId]
        );
        
        if (!rows.length) {
            return res.status(404).json({ 
                success: false, 
                message: 'ไม่พบคำแจ้งซ่อม' 
            });
        }
        
        res.json({ 
            success: true, 
            data: rows[0] || { repair_cost: 0, cost_note: '' } 
        });
        
    } catch (err) {
        res.status(500).json({ 
            success: false, 
            message: err.message 
        });
    }
});

// GET /api/reports/cost-summary
app.get('/api/reports/cost-summary', authMiddleware, adminMiddleware, async (req, res) => {
    const { year, month } = req.query;
    let sql = `SELECT 
                SUM(repair_cost) as total_cost,
                COUNT(*) as total_repairs,
                AVG(repair_cost) as avg_cost,
                MONTH(requested_at) as month,
                YEAR(requested_at) as year
               FROM repair_requests 
               WHERE repair_cost > 0`;
    const params = [];
    
    if (year) {
        sql += ' AND YEAR(requested_at) = ?';
        params.push(year);
    }
    if (month) {
        sql += ' AND MONTH(requested_at) = ?';
        params.push(month);
    }
    
    sql += ' GROUP BY YEAR(requested_at), MONTH(requested_at) ORDER BY year DESC, month DESC';
    
    try {
        const [rows] = await db.query(sql, params);
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// POST /api/users - สร้างผู้ใช้ใหม่ (Admin เท่านั้น)
app.post('/api/users', authMiddleware, adminMiddleware, async (req, res) => {
  const { username, full_name, email, phone, password, role } = req.body;
  
  if (!username || !full_name || !password) {
    return res.status(400).json({ success: false, message: 'กรุณากรอกข้อมูลที่จำเป็น' });
  }
  
  try {
    const [existing] = await db.query('SELECT id FROM users WHERE username = ?', [username]);
    if (existing.length) {
      return res.status(409).json({ success: false, message: 'ชื่อผู้ใช้นี้มีอยู่แล้ว' });
    }
    
    const hashedPassword = await bcrypt.hash(password, 10);
    await db.query(
      'INSERT INTO users (username, full_name, email, phone, password, role, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [username, full_name, email, phone, hashedPassword, role || 'user', 'active']
    );
    
    res.json({ success: true, message: 'เพิ่มผู้ใช้สำเร็จ' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/users/:id - ลบผู้ใช้
app.delete('/api/users/:id', authMiddleware, adminMiddleware, async (req, res) => {
  const id = req.params.id;
  
  if (parseInt(id) === req.user.id) {
    return res.status(400).json({ success: false, message: 'ไม่สามารถลบบัญชีของตัวเองได้' });
  }
  
  try {
    await db.query('DELETE FROM users WHERE id = ?', [id]);
    res.json({ success: true, message: 'ลบผู้ใช้สำเร็จ' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// =============================================
// Route: สร้าง Excel เอกสารขอซ่อม
// =============================================
app.get('/api/export-repair-doc/:id', authMiddleware, async (req, res) => {
    try {
        const repairId = req.params.id;
        
        // ดึงข้อมูลคำแจ้งซ่อม
        const [rows] = await db.query(
            `SELECT rr.*, e.equipment_code, e.equipment_name, et.name as type_name 
             FROM repair_requests rr
             JOIN equipment e ON rr.equipment_id = e.id
             JOIN equipment_types et ON e.equipment_type_id = et.id
             WHERE rr.id = ?`,
            [repairId]
        );
        
        if (!rows.length) {
            return res.status(404).json({ success: false, message: 'ไม่พบข้อมูล' });
        }
        
        const r = rows[0];
        
        // วันที่
        const now = new Date();
        const thaiMonths = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
        const dateStr = `${now.getDate()} ${thaiMonths[now.getMonth()]} ${now.getFullYear()+543}`;
        
        // แปลงเงินเป็นตัวเลขไทย
        function numberToThaiText(num) {
            if (num === 0 || isNaN(num) || num === '') return 'ศูนย์บาทถ้วน';
            
            const digits = ['', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'];
            const units = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน'];
            
            let text = '';
            let str = String(Math.round(parseFloat(num)));
            let len = str.length;
            
            for (let i = 0; i < len; i++) {
                const digit = parseInt(str[i]);
                const pos = len - i - 1;
                if (digit > 0) {
                    if (pos === 1 && digit === 1) {
                        text += 'สิบ';
                    } else if (pos === 1 && digit === 2) {
                        text += 'ยี่สิบ';
                    } else if (pos === 0 && digit === 1 && len > 1) {
                        text += 'เอ็ด';
                    } else {
                        text += digits[digit] + units[pos];
                    }
                }
            }
            return text + 'บาทถ้วน';
        }
        
        // แยกรายการชิ้นส่วน
        const partsList = r.equipment_parts ? r.equipment_parts.split(',').map(p => p.trim()) : ['ไม่มีรายการ'];
        
        // =============================================
        // สร้างข้อมูล Excel
        // =============================================
        const excelData = [];
        
        // แถวที่ 1: หัวข้อ
        excelData.push(['', '', '', '', '', '', '', 'บันทึกข้อความ', '', '', '', '', '', '', '', '']);
        excelData.push([]);
        
        // แถวที่ 2: ส่วนราชการ
        excelData.push(['', 'ส่วนราชการ', '', '', '', '', '', 'โรงพยาบาลเหนือคลอง อำเภอเหนือคลอง จังหวัดกระบี่ โทร.0-7569-1801', '', '', '', '', '', '', '', '']);
        
        // แถวที่ 3: ที่ / วันที่
        excelData.push(['', 'ที่', 'กบ 0033.3/7/', '', '', '', '', 'วันที่', '', dateStr, '', '', '', '', 'พ.ศ.', '']);
        
        // แถวที่ 4: เรื่อง
        excelData.push(['', 'เรื่อง', '', 'ขออนุมัติซ่อมบำรุงวัสดุ/ครุภัณฑ์ ประเภท', '', '', '', '', '', r.type_name || 'ครุภัณฑ์คอมพิวเตอร์', '', '', '', '', '', '']);
        
        // แถวที่ 5: เรียน
        excelData.push(['', 'เรียน', '', 'ผู้อำนวยการโรงพยาบาลเหนือคลอง', '', '', '', '', '', '', '', '', '', '', '', '']);
        excelData.push([]);
        
        // แถวที่ 6: เนื้อหา
        excelData.push(['', '', '', 'ด้วย งาน/ฝ่าย', '', '', '', '', r.location_department || 'กลุ่มงานสุขภาพดิจิทัล', '', '', '', '', '', 'มีความประสงค์ซ่อมบำรุงดังนี้', '']);
        
        // แถวที่ 7-11: รายการ (5 รายการ)
        for (let i = 0; i < 5; i++) {
            const partName = i < partsList.length ? partsList[i] : '';
            excelData.push(['', `${i+1}.`, partName || '', '', '', '', '', '', '', '', '', '', '', '', 'จำนวน', '1']);
        }
        
        // แถวที่ 12: รวมเงิน
        const cost = parseFloat(r.repair_cost) || 0;
        excelData.push(['', 'รวมเงินประมาณ', '', '', '', '', '', '', cost.toFixed(2), 'บาท', '', '(', numberToThaiText(cost), '', '', ')']);
        
        // แถวที่ 13: เสนอชื่อผู้ตรวจรับ
        excelData.push(['', '', '', '', '', '', '', 'เสนอชื่อผู้ตรวจรับพัสดุดังนี้', '', '', '', '', '', '', '', '']);
        
        // แถวที่ 14-16: ผู้ตรวจรับ
        excelData.push(['', '1.', '', '', '', '', '', '', '', '', '', '', 'ประธานกรรมการ/จนท.ตรวจรับ', '', '', '']);
        excelData.push(['', '2.', '', '', '', '', '', '', '', '', '', '', 'กรรมการ', '', '', '']);
        excelData.push(['', '3.', '', '', '', '', '', '', '', '', '', '', 'กรรมการ', '', '', '']);
        excelData.push([]);
        
        // แถวที่ 17: สรุป
        excelData.push(['', '', '', 'จึงเรียนมาเพื่อโปรดทราบและพิจารณาอนุมัติ', '', '', '', '', '', '', '', '', '', '', '', '']);
        excelData.push([]);
        
        // แถวที่ 18: ลายเซ็นผู้ส่งซ่อม
        excelData.push(['', '', '', '', '', '', '', 'ลงชื่อ', '', '', '', '', 'ผู้ส่งซ่อม', '', '', '']);
        excelData.push(['', '', '', '', '', '', '', '', '(', r.requester_name || '', ')', '', '', '', '', '']);
        excelData.push([]);
        
        // แถวที่ 19: บันทึกของหน่วยซ่อมบำรุง
        excelData.push(['', '', '', '', '', '', 'บันทึกของหน่วยซ่อมบำรุง', '', '', '', '', '', '', '', '', '']);
        excelData.push(['', '', 'ซ่อมเองได้', '', '', '', '', '', '', 'ไม่สามารถซ่อมเองได้ต้องส่งซ่อม', '', '', '', '', 'ใช้เวลาประมาณ', '______ วัน']);
        
        excelData.push([]);
        excelData.push([]);
        
        // ช่างซ่อม
        excelData.push(['', '', '', '', '', '', '', '', '', '', '', '', 'ช่างซ่อมบำรุง', '', '', '']);
        excelData.push(['ลงชื่อ', '', '', '', '', '', '', '', '', '', '', '', ')', '', '', '']);
        excelData.push(['', '', 'วันที่', '', '', '', '', '', 'วันที่', '', '', '', '', 'วันที่', '', '']);
        
        excelData.push(['ลงชื่อ', '', '', '', '', '', '', '', '', '', '', 'หัวหน้างานซ่อมบำรุง', '', '', '', '']);
        excelData.push(['', '', 'วันที่', '', '', '', '', '', 'วันที่', '', '', '', '', 'วันที่', '', '']);
        
        excelData.push(['ลงชื่อ', '', '', '', '', '', '', '', '', '', '', 'เจ้าของงาน', '', '', '', '']);
        excelData.push([]);
        
        // อนุมัติ
        excelData.push(['', '', '', 'เสนอ ผู้อำนวยการโรงพยาบาลเหนือคลอง', '', '', '', '', '', '', '', '', 'อนุมัติ', '', 'ไม่อนุมัติ', '']);
        excelData.push(['', '', 'เพื่อโปรดทราบ และเห็นควรอนุมัติ', '', '', '', '', '', '', '', '', '', '', '', '', '']);
        excelData.push(['', '', 'ลงชื่อ', '', '', '', '', '', '', '', '', '', 'ลงชื่อ', '', '', '']);
        
        // =============================================
        // สร้าง Excel File
        // =============================================
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet(excelData);
        
        ws['!cols'] = [
            { wch: 4 }, { wch: 12 }, { wch: 15 }, { wch: 20 }, { wch: 4 },
            { wch: 4 }, { wch: 4 }, { wch: 15 }, { wch: 4 }, { wch: 20 },
            { wch: 4 }, { wch: 4 }, { wch: 20 }, { wch: 4 }, { wch: 15 }, { wch: 10 }
        ];
        
        XLSX.utils.book_append_sheet(wb, ws, '68_ขอซ่อม');
        
        const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
        
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename=ขอซ่อม_${r.ticket_number}.xlsx`);
        res.send(buffer);
        
    } catch (err) {
        console.error('Export error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// Proxy: ส่งข้อมูลไป Google Apps Script (แก้ CORS)
// =============================================
app.post('/api/proxy-gas', authMiddleware, async (req, res) => {
    const { gasUrl, payload } = req.body;

    if (!gasUrl || !payload) {
        return res.status(400).json({ success: false, message: 'กรุณาระบุ gasUrl และ payload' });
    }

    // Validate URL
    if (!gasUrl.startsWith('https://script.google.com/macros/s/')) {
        return res.status(400).json({ success: false, message: 'URL ไม่ถูกต้อง ต้องขึ้นต้นด้วย https://script.google.com/macros/s/' });
    }

    try {
        console.log('🔄 Proxying to GAS:', gasUrl.substring(0, 60) + '...');

        // Node 18+ has native fetch — use AbortController for timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);

        const response = await fetch(gasUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        const text = await response.text();
        console.log('📥 GAS Response status:', response.status);

        // Try to parse as JSON
        let data;
        try {
            data = JSON.parse(text);
        } catch {
            data = { raw: text };
        }

        if (response.ok) {
            res.json({ success: true, data });
        } else {
            res.status(response.status).json({ success: false, message: 'GAS returned error', status: response.status, data });
        }

    } catch (err) {
        console.error('❌ Proxy error:', err.message);
        res.status(502).json({ success: false, message: 'Proxy error: ' + err.message });
    }
});

// =============================================
// DELETE /api/repairs/:id - ลบคำร้องขอซ่อม (เฉพาะ Admin)
// =============================================
app.delete('/api/repairs/:id', authMiddleware, adminMiddleware, async (req, res) => {
    const repairId = req.params.id;
    
    try {
        // ตรวจสอบว่ามีรายการนี้หรือไม่
        const [rows] = await db.query('SELECT id, ticket_number FROM repair_requests WHERE id = ?', [repairId]);
        if (!rows.length) {
            return res.status(404).json({ success: false, message: 'ไม่พบคำแจ้งซ่อม' });
        }
        
        // ลบข้อมูล (ตาราง status_history จะถูกลบอัตโนมัติเพราะมี ON DELETE CASCADE)
        await db.query('DELETE FROM repair_requests WHERE id = ?', [repairId]);
        
        res.json({ 
            success: true, 
            message: `ลบคำร้องขอซ่อมหมายเลข ${rows[0].ticket_number} สำเร็จ`,
            deletedId: repairId
        });
        
    } catch (err) {
        console.error('Error deleting repair:', err);
        res.status(500).json({ 
            success: false, 
            message: 'เกิดข้อผิดพลาด: ' + err.message 
        });
    }
});

// =============================================
// NEW: Manager Dashboard Stats
// =============================================
app.get('/api/manager/stats', authMiddleware, managerMiddleware, async (req, res) => {
    try {
        // หา department ที่ manager คนนี้ดูแล
        let whereClause = '';
        let params = [];
        if (req.user.role === 'manager') {
            // Manager ดูเฉพาะของ department ตนเอง
            const [dept] = await db.query('SELECT id FROM departments WHERE manager_id = ?', [req.user.id]);
            if (dept.length > 0) {
                const deptIds = dept.map(d => d.id);
                whereClause = ' AND rr.department_id IN (' + deptIds.join(',') + ')';
            } else {
                whereClause = ' AND rr.department_id IS NULL';
            }
        }

        const [totalRows] = await db.query('SELECT COUNT(*) as total FROM repair_requests rr WHERE 1=1' + whereClause, params);
        const [pendingRows] = await db.query(`SELECT COUNT(*) as pending FROM repair_requests rr WHERE rr.status='pending'${whereClause}`, params);
        const [approvedRows] = await db.query(`SELECT COUNT(*) as approved FROM repair_requests rr WHERE rr.status='in_progress'${whereClause}`, params);
        const [completedRows] = await db.query(`SELECT COUNT(*) as completed FROM repair_requests rr WHERE rr.status='completed'${whereClause}`, params);
        const [urgentRows] = await db.query(`SELECT COUNT(*) as urgent FROM repair_requests rr WHERE rr.priority='urgent' AND rr.status NOT IN ('completed','cancelled')${whereClause}`, params);

        res.json({
            success: true,
            stats: {
                total: totalRows[0]?.total || 0,
                pending: pendingRows[0]?.pending || 0,
                approved: approvedRows[0]?.approved || 0,
                completed: completedRows[0]?.completed || 0,
                urgent: urgentRows[0]?.urgent || 0
            }
        });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// NEW: Notifications API
// =============================================

// GET /api/notifications - ดึงการแจ้งเตือนของผู้ใช้
app.get('/api/notifications', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
            [req.user.id]
        );
        const [unread] = await db.query(
            'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0',
            [req.user.id]
        );
        res.json({ success: true, data: rows, unread: unread[0]?.count || 0 });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// PATCH /api/notifications/read/:id - mark as read
app.patch('/api/notifications/read/:id', authMiddleware, async (req, res) => {
    try {
        await db.query('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// PATCH /api/notifications/read-all - mark all as read
app.patch('/api/notifications/read-all', authMiddleware, async (req, res) => {
    try {
        await db.query('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [req.user.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// NEW: Departments API (Admin)
// =============================================

// GET /api/departments - รายการแผนกทั้งหมด
app.get('/api/departments', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT d.*, u.full_name as manager_name FROM departments d LEFT JOIN users u ON d.manager_id = u.id ORDER BY d.name'
        );
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// POST /api/departments - เพิ่มแผนก (Admin เท่านั้น)
app.post('/api/departments', authMiddleware, adminMiddleware, async (req, res) => {
    const { name, description, manager_id } = req.body;
    if (!name) return res.status(400).json({ success: false, message: 'กรุณากรอกชื่อแผนก' });
    try {
        await db.query(
            'INSERT INTO departments (name, description, manager_id) VALUES (?, ?, ?)',
            [name, description || null, manager_id || null]
        );
        res.json({ success: true, message: 'เพิ่มแผนกสำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// PUT /api/departments/:id - แก้ไขแผนก (Admin)
app.put('/api/departments/:id', authMiddleware, adminMiddleware, async (req, res) => {
    const { name, description, manager_id } = req.body;
    try {
        await db.query(
            'UPDATE departments SET name = ?, description = ?, manager_id = ? WHERE id = ?',
            [name, description || null, manager_id || null, req.params.id]
        );
        res.json({ success: true, message: 'อัพเดตแผนกสำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// DELETE /api/departments/:id - ลบแผนก (Admin)
app.delete('/api/departments/:id', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        await db.query('DELETE FROM departments WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'ลบแผนกสำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// NEW: Manager Approve/Reject Workflow
// =============================================

// POST /api/repairs/:id/approve - Manager อนุมัติ
app.post('/api/repairs/:id/approve', authMiddleware, managerMiddleware, async (req, res) => {
    const repairId = req.params.id;
    try {
        const [rows] = await db.query('SELECT id, status, ticket_number, requester_name FROM repair_requests WHERE id = ?', [repairId]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'ไม่พบคำแจ้งซ่อม' });

        const oldStatus = rows[0].status;
        if (oldStatus !== 'pending') {
            return res.status(400).json({ success: false, message: 'เฉพาะคำขอที่รอดำเนินการเท่านั้นที่สามารถอนุมัติได้' });
        }

        // ตรวจสอบว่า manager ดูแล department นี้หรือไม่
        if (req.user.role === 'manager') {
            const [dept] = await db.query('SELECT id FROM departments WHERE manager_id = ?', [req.user.id]);
            if (dept.length === 0) {
                return res.status(403).json({ success: false, message: 'คุณไม่มีสิทธิ์อนุมัติคำขอนี้' });
            }
        }

        await db.query(
            'UPDATE repair_requests SET status = ?, approved_by = ?, approved_at = NOW(), updated_at = NOW() WHERE id = ?',
            ['in_progress', req.user.id, repairId]
        );
        await db.query(
            'INSERT INTO status_history (repair_request_id, old_status, new_status, changed_by, note) VALUES (?, ?, ?, ?, ?)',
            [repairId, oldStatus, 'in_progress', req.user.id, 'อนุมัติโดย Manager']
        );

        // สร้าง notification แจ้ง Admin
        await db.query(
            'INSERT INTO notifications (user_id, title, message, type, related_type, related_id) VALUES (?, ?, ?, ?, ?, ?)',
            [1, '✅ มีคำขอที่ได้รับการอนุมัติ', `คำขอซ่อม #${rows[0].ticket_number} ได้รับการอนุมัติแล้ว กรุณาดำเนินการ`, 'success', 'repair', repairId]
        );

        res.json({ success: true, message: 'อนุมัติคำแจ้งซ่อมสำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// POST /api/repairs/:id/reject - Manager ไม่อนุมัติ
app.post('/api/repairs/:id/reject', authMiddleware, managerMiddleware, async (req, res) => {
    const repairId = req.params.id;
    const { reason } = req.body;
    try {
        const [rows] = await db.query('SELECT id, status, ticket_number FROM repair_requests WHERE id = ?', [repairId]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'ไม่พบคำแจ้งซ่อม' });

        const oldStatus = rows[0].status;
        if (oldStatus !== 'pending') {
            return res.status(400).json({ success: false, message: 'เฉพาะคำขอที่รอดำเนินการเท่านั้น' });
        }

        await db.query(
            'UPDATE repair_requests SET status = ?, approved_by = ?, admin_note = ?, updated_at = NOW() WHERE id = ?',
            ['cancelled', req.user.id, reason || 'ไม่อนุมัติโดย Manager', repairId]
        );
        await db.query(
            'INSERT INTO status_history (repair_request_id, old_status, new_status, changed_by, note) VALUES (?, ?, ?, ?, ?)',
            [repairId, oldStatus, 'cancelled', req.user.id, reason || 'ไม่อนุมัติ']
        );

        // แจ้ง Admin
        await db.query(
            'INSERT INTO notifications (user_id, title, message, type, related_type, related_id) VALUES (?, ?, ?, ?, ?, ?)',
            [1, '❌ คำขอถูกปฏิเสธ', `คำขอซ่อม #${rows[0].ticket_number} ถูกปฏิเสธ: ${reason || 'ไม่มีเหตุผล'}`, 'error', 'repair', repairId]
        );

        res.json({ success: true, message: 'ปฏิเสธคำแจ้งซ่อมสำเร็จ' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// =============================================
// NEW: Helper to create notification when new repair is created
// =============================================
// (Patch existing POST /api/repairs to also notify)
// We'll add notification in the existing POST /api/repairs route - done inline below
// Actually need to inject it. Let's replace the existing POST /api/repairs

// =============================================
// Serve Frontend (SPA)
// =============================================
app.get('*', (req, res) => {
    // ถ้าเป็น API path ให้ตอบ 404 json
    if (req.path.startsWith('/api/')) {
        return res.status(404).json({ success: false, message: 'API endpoint not found' });
    }
    // หน้าอื่นๆ (html) ให้ส่งไฟล์ตาม path หรือ index.html
    const filePath = path.join(__dirname, req.path);
    if (fs.existsSync(filePath) && path.extname(filePath)) {
        return res.sendFile(filePath);
    }
    res.sendFile(path.join(__dirname, 'index.html'));
});

// =============================================
// Start Server
// =============================================
connectDB().then(() => {
    app.listen(PORT, () => {
        console.log(`🚀 Server รันที่ http://localhost:${PORT}`);
        console.log(`📊 Admin Dashboard: http://localhost:${PORT}`);
    });
});

// ===== Change Password =====
app.post('/api/profile/change-password', authenticateToken, async (req, res) => {
  const userId = req.user.id;
  const { current_password, new_password } = req.body;
  
  if (!current_password || !new_password) {
    return res.status(400).json({ success: false, message: 'กรุณากรอกข้อมูลให้ครบถ้วน' });
  }
  
  if (new_password.length < 6) {
    return res.status(400).json({ success: false, message: 'รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร' });
  }
  
  try {
    // ตรวจสอบรหัสผ่านปัจจุบัน
    const [users] = await db.query('SELECT password FROM users WHERE id = ?', [userId]);
    if (users.length === 0) {
      return res.status(404).json({ success: false, message: 'ไม่พบผู้ใช้' });
    }
    
    const valid = await bcrypt.compare(current_password, users[0].password);
    if (!valid) {
      return res.status(400).json({ success: false, message: 'รหัสผ่านปัจจุบันไม่ถูกต้อง' });
    }
    
    // อัปเดตรหัสผ่านใหม่
    const hashed = await bcrypt.hash(new_password, 10);
    await db.query('UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?', [hashed, userId]);
    
    res.json({ success: true, message: 'เปลี่ยนรหัสผ่านสำเร็จ' });
  } catch (err) {
    console.error('Change password error:', err);
    res.status(500).json({ success: false, message: 'เกิดข้อผิดพลาดในระบบ' });
  }
});